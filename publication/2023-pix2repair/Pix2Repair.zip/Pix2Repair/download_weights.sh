#!/bin/bash

mkdir -p experiments/pix2repair_all/checkpoints
cd experiments/pix2repair_all/checkpoints
echo "Downloading pix2repair checkpoint..."
gdown -q 11v0mZq3WDR5pKroYgqPFYTTQj0ex1rG_