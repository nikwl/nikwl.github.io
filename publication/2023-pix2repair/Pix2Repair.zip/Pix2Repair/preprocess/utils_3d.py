import logging

import trimesh
import numpy as np


def grid_sample_points(
    n=256,
    padding=0.1,
):
    """Return n^3 points uniformally spaced in a unit cube"""
    grid_pts = np.meshgrid(
        *[np.linspace(0, 1.0 + (padding * 2), d) - (0.5 + padding) for d in (n, n, n)]
    )
    return np.vstack([p.flatten() for p in grid_pts]).T


def force_trimesh(mesh, remove_texture=False):
    """
    Forces a mesh or list of meshes to be a single trimesh object.
    """

    if isinstance(mesh, list):
        return [force_trimesh(m) for m in mesh]

    if isinstance(mesh, trimesh.Scene):
        if len(mesh.geometry) == 0:
            mesh = trimesh.Trimesh()
        else:
            mesh = trimesh.util.concatenate(
                tuple(
                    trimesh.Trimesh(vertices=g.vertices, faces=g.faces)
                    for g in mesh.geometry.values()
                )
            )
    if remove_texture:
        mesh = trimesh.Trimesh(vertices=mesh.vertices, faces=mesh.faces)
    return mesh


def intersect_mesh(a, b, sig=5):
    """mask of vertices that a shares with b"""
    av = [frozenset(np.round(v, sig)) for v in a]
    bv = set([frozenset(np.round(v, sig)) for v in b])
    return np.asarray(list(map(lambda v: v in bv, av))).astype(bool)


def get_faces_from_vertices(vertex_mask, faces, inclusive=False):
    """Get faces containting vertices"""
    vertex_index = set(np.nonzero(vertex_mask)[0])
    face_mask = np.zeros((faces.shape[0],))
    for idx, f in enumerate(faces):
        if inclusive:
            if f[0] in vertex_index and f[1] in vertex_index and f[2] in vertex_index:
                face_mask[idx] = 1
        else:
            if f[0] in vertex_index or f[1] in vertex_index or f[2] in vertex_index:
                face_mask[idx] = 1
    return face_mask.astype(bool)


def get_fracture_points(b, r):
    """Get broken points on the fracture"""
    vb, vr = b.vertices, r.vertices
    logging.debug(
        "Computing fracture points for meshes with size {} and {} ...".format(
            vb.shape[0], vr.shape[0]
        )
    )
    return intersect_mesh(vb, vr)


def get_fracture_points_c(b, c):
    """Get broken points on the fracture"""
    vb, vc = b.vertices, c.vertices
    logging.debug(
        "Computing fracture points for meshes with size {} and {} ...".format(
            vb.shape[0], vc.shape[0]
        )
    )
    return ~intersect_mesh(vb, vc)


def get_close_fracture_points(b, r, threshold):
    """Get broken points close to the fracture"""
    return r.kdtree.query(b.vertices)[0] < threshold


def get_close_fracture_points_c(b, c, threshold):
    """Get broken points close to the fracture"""
    return c.kdtree.query(b.vertices)[0] > threshold


def get_boundary_indices(mesh):
    """Get indices of vertices that only appear once (boundary indices)"""
    index = trimesh.grouping.group_rows(mesh.edges_sorted, require_count=1)
    return np.unique(mesh.edges[index].flatten())
