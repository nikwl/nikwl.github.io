import os
import logging
import argparse
import random
import multiprocessing as mp

import tqdm
import trimesh
import numpy as np

import utils
import utils_3d

from libmesh import check_mesh_contains


def run(path):
    f_in, f_out = path

    try:
        if os.path.exists(f_out) and not OVERWRITE:
            logging.debug(f"Skipped {f_in}")
            return
        logging.debug(f"Running {f_in}")

        mesh = trimesh.load(f_in)
        occ = check_mesh_contains(mesh, PTS).astype(bool)

        logging.debug(f"Saving {f_out}")
        np.savez(
            f_out,
            occ=np.packbits(occ),
        )

    except Exception as e:
        if args.debug:
            raise e
        print(f"{e} error running {f_out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("split", type=str)
    parser.add_argument("--overwrite", action="store_true", default=False)
    parser.add_argument("--num_workers", type=int, default=mp.cpu_count() - 1)
    parser.add_argument("--dim", type=int, default=256)
    parser.add_argument("--shape", type=str, default="r")
    utils.add_common_args(parser)
    args = parser.parse_args()
    utils.configure_logging(args)

    if args.debug:
        args.num_workers = 1
    assert args.shape in ["c", "b", "r"]
    OVERWRITE = args.overwrite
    PTS = utils_3d.grid_sample_points(args.dim)

    split = utils.load_split(args.split)

    if args.shape == "r":
        input_template = "model_r_{}.obj"
    elif args.shape == "b":
        input_template = "model_b_{}.obj"
    elif args.shape == "c":
        input_template = "model_c.obj"

    paths = []
    for s in ["train", "val", "test"]:
        for o in split[s]:
            paths.append(
                [
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "models",
                        input_template.format(o["break_id"]),
                    ),
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "models",
                        "model_{}_{}_vox{}.npz".format(
                            args.shape, o["break_id"], args.dim
                        ),
                    ),
                ]
            )

    if args.fast_dev_run:
        run(paths[0])
        exit(0)

    logging.info(f"Found {len(paths)} files")
    p = mp.Pool(args.num_workers)
    if not args.debug:
        random.shuffle(paths)
    for _ in tqdm.tqdm(p.imap_unordered(run, paths), total=len(paths)):
        pass
