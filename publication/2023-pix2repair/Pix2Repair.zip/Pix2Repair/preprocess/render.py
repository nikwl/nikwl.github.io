import logging
import os
import argparse
import random
import multiprocessing as mp

import tqdm
import trimesh
import numpy as np
from PIL import Image
import pyrender
os.environ["PYOPENGL_PLATFORM"] = "egl"

import utils
import utils_3d


def trimesh_force(mesh):
    """Convert a trimesh scene into a mesh"""

    if isinstance(mesh, list):
        return [trimesh_force(m) for m in mesh]

    if isinstance(mesh, trimesh.Scene):
        if len(mesh.geometry) == 0:
            mesh = trimesh.Trimesh()
        else:
            mesh = trimesh.util.concatenate(
                tuple(
                    trimesh.Trimesh(vertices=g.vertices, faces=g.faces)
                    if hasattr(g, "visual")
                    else trimesh.Trimesh(
                        vertices=g.vertices, faces=g.faces, visual=g.visual
                    )
                    for g in mesh.geometry.values()
                )
            )

    return mesh


def _is_sized(mesh):
    """Check if the model might be too large to be viewable in the renderer"""
    if not isinstance(mesh, list):
        mesh = [mesh]
    vertices = np.vstack(
        [
            m.vertices
            if isinstance(m, trimesh.PointCloud) or isinstance(m, trimesh.Trimesh)
            else m
            for m in trimesh_force(mesh)
        ]
    )
    max_ptp = max(vertices.ptp(axis=0))
    if max_ptp > 100:
        logging.warn(
            "Max PTP value of {} is unlikely to be viewable, try scaling your model down".format(
                max_ptp
            )
        )
        return False
    return True


def render(
    mesh,
    modality="color",
    fov=(np.pi / 4.0),
    resolution=(1280, 720),
    xtrans=0.0,
    ytrans=0.0,
    ztrans=2.0,
    xrot=-25.0,
    yrot=45.0,
    zrot=0.0,
    camera_pose=None,
    spotlight_intensity=8.0,
    remove_texture=False,
    wireframe=False,
    bg_color=255,
    mode="RGB",
    point_size=5,
    **kwargs,
):
    """Render a trimesh object or list of objects"""

    assert modality in ["color", "depth"]

    # Create a pyrender scene with ambient light
    scene = pyrender.Scene(ambient_light=np.ones(3), bg_color=bg_color, **kwargs)

    # Convert all scenes to meshes
    mesh = trimesh_force(mesh)

    # Check if the model is likely to be the correct size
    _is_sized(mesh)

    # Convert inputs to lists if necessary
    if not isinstance(mesh, list):
        mesh = [mesh]
    if not isinstance(wireframe, list):
        wireframe = [wireframe] * len(mesh)

    # Strip texture out of meshes
    if remove_texture:
        for i in range(len(mesh)):
            if isinstance(mesh[i], trimesh.Trimesh):
                mesh[i] = trimesh.Trimesh(
                    vertices=mesh[i].vertices, faces=mesh[i].faces
                )

    # Convert the input meshes into pyrender meshes
    for m, w in zip(mesh, wireframe):
        if isinstance(m, trimesh.points.PointCloud):
            logging.debug("Parsed pointcloud")
            if m.colors.shape[0] == 0:
                colors = np.array((0, 0, 0, 0))
            else:
                colors = m.colors
            scene.add(pyrender.Mesh.from_points(m.vertices, colors=colors))
        elif isinstance(m, trimesh.Trimesh):
            logging.debug("Parsed mesh")
            scene.add(pyrender.Mesh.from_trimesh(m, wireframe=w))
        else:
            logging.debug("Parsed vertex set")
            scene.add(pyrender.Mesh.from_points(m, colors=colors))

    # Create the camera with the correct aspect ratio
    aspect_ratio = resolution[0] / resolution[1]
    camera = pyrender.PerspectiveCamera(
        yfov=fov,
        aspectRatio=aspect_ratio,
    )

    # Apply translations
    if camera_pose is None:
        trans = np.array(
            [
                [1.0, 0.0, 0.0, xtrans],
                [0.0, 1.0, 0.0, ytrans],
                [0.0, 0.0, 1.0, ztrans],
                [0.0, 0.0, 0.0, 1.0],
            ]
        )

        # Apply rotations
        xrotmat = trimesh.transformations.rotation_matrix(
            angle=np.radians(xrot), direction=[1, 0, 0], point=(0, 0, 0)
        )
        camera_pose = np.dot(xrotmat, trans)
        yrotmat = trimesh.transformations.rotation_matrix(
            angle=np.radians(yrot), direction=[0, 1, 0], point=(0, 0, 0)
        )
        camera_pose = np.dot(yrotmat, camera_pose)
        zrotmat = trimesh.transformations.rotation_matrix(
            angle=np.radians(zrot), direction=[0, 0, 1], point=(0, 0, 0)
        )
        camera_pose = np.dot(zrotmat, camera_pose)
    logging.debug("Creating camera with pose: \n{}".format(camera_pose))

    # Insert the camera
    scene.add(camera, pose=camera_pose)

    # Insert a spotlight to give contrast
    spot_light = pyrender.SpotLight(
        color=np.ones(3),
        intensity=spotlight_intensity,
        innerConeAngle=np.pi / 16.0,
        outerConeAngle=np.pi / 6.0,
    )
    scene.add(spot_light, pose=camera_pose)

    # Render
    r = pyrender.OffscreenRenderer(resolution[0], resolution[1], point_size=point_size)
    c, d = r.render(scene)
    if modality == "depth":
        return np.array(d)
    elif modality == "color":
        if mode is None:
            return np.array(c)
        return np.array(Image.fromarray(c).convert(mode))
    else:
        raise RuntimeError
    

def extrinsic_matrix(from_vec, to_vec):
    """Constructs a look-at extrinsic camera matrix, of the form:
    [right, up, fwd, at]
    """
    fwd = from_vec - to_vec
    fwd /= np.linalg.norm(fwd)
    right = np.cross((0, 1, 0), fwd)  # Assume up vector is (0, 1, 0)
    up = np.cross(fwd, right)

    mat = np.eye(4)
    mat[:3, 0] = right
    mat[:3, 1] = up
    mat[:3, 2] = fwd
    mat[:3, 3] = from_vec
    return mat


def object_in_frame(render):
    """Is the object fully in the camera frame?"""
    h, w, _ = render.shape
    edge_mask = np.pad(np.zeros((h - 2, w - 2)), 1, constant_values=1).astype(bool)
    render = render.astype(float).sum(axis=2) == (255 * 3)  # white pixels
    masked_render = (edge_mask * render).astype(bool)  # white pixels on edge
    return masked_render.sum() == edge_mask.sum()  # all edge pixels must be white


def all_white_render(render):
    """Is the frame all white?"""
    return render.sum() == (np.ones(render.shape) * 255).sum()


def run(path):
    f_in_c, f_in_b, f_in_r, f_out_img, f_out_depth, f_out_meta = path

    try:
        if os.path.exists(f_out_img) and os.path.exists(f_out_depth) and not OVERWRITE:
            logging.debug(f"Skipped {f_in_b}")
            return
        logging.debug(f"Running {f_in_b}")

        if not os.path.exists(os.path.dirname(f_out_img)):
            os.mkdir(os.path.dirname(f_out_img))

        mesh_c = utils_3d.force_trimesh(trimesh.load(f_in_c, force=True))
        mesh_b = utils_3d.force_trimesh(trimesh.load(f_in_b, force=True))

        # Fit a plane and get the normal
        fracture_vertex_mask = utils_3d.get_close_fracture_points_c(
            mesh_b, mesh_c, threshold=0.005
        )

        # Fit a plane and get the normal
        assert fracture_vertex_mask.sum() != 0
        fracture_vertices = mesh_b.vertices[fracture_vertex_mask, :]
        _, n = trimesh.points.plane_fit(fracture_vertices)
        n /= np.linalg.norm(n)

        # Get the center of the bounding box that surrounds the fracture vs
        mesh_min = np.min(fracture_vertices, axis=0)
        mesh_max = np.max(fracture_vertices, axis=0)
        fracture_center = ((mesh_max - mesh_min) / 2.0) + mesh_min

        # The plane normal should be pointing away from the broken part
        if np.dot(mesh_b.vertices - fracture_center, n).mean() > 0:
            n = -n

        def try_render(n):
            cam_scale = 1.0
            for _ in range(RETRIES):
                # Camera center is just the centroid plus the plane normal
                camera_center = fracture_center + n * cam_scale

                # Get the camera pose in opengl style
                camera_pose = extrinsic_matrix(camera_center, fracture_center)

                # Render the mesh
                render = render(
                    mesh_b,
                    resolution=(224, 224),
                    camera_pose=camera_pose,
                    spotlight_intensity=8.0,
                )

                if not all_white_render(render) and object_in_frame(render):
                    break

                # Move the camera farther back and try again
                cam_scale *= 1.2

            return render, camera_pose

        # Try to render the object with the normal and the opposite normal
        render, camera_pose = try_render(n)
        if all_white_render(render) or not object_in_frame(render):
            render, camera_pose = try_render(-n)

        # This is an all white image
        assert not all_white_render(render)

        # Render it again with depth
        depth = render(
            mesh_b,
            modality="depth",
            resolution=(224, 224),
            camera_pose=camera_pose,
            spotlight_intensity=8.0,
        )

        logging.debug(f"Saving {f_out_img}")
        Image.fromarray(render).save(f_out_img)

        logging.debug(f"Saving {f_out_depth}")
        np.save(f_out_depth, depth)

        logging.debug(f"Saving {f_out_meta}")
        np.savez(
            f_out_meta,
            camera_pose=camera_pose,
        )

    except Exception as e:
        if args.debug:
            raise e
        print(f"{e} error running {f_in_b}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("split", type=str)
    parser.add_argument("--overwrite", action="store_true", default=False)
    parser.add_argument("--num_workers", type=int, default=mp.cpu_count() - 1)
    parser.add_argument("--num_retries", type=int, default=20)
    utils.add_common_args(parser)
    args = parser.parse_args()
    utils.configure_logging(args)

    if args.debug:
        args.num_workers = 1
    OVERWRITE = args.overwrite
    RETRIES = args.num_retries

    split = utils.load_split(args.split)

    paths = []
    for s in ["train", "test", "val"]:
        for o in split[s]:
            paths.append(
                [
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "models",
                        "model_c.obj",
                    ),
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "models",
                        "model_b_{}.obj".format(o["break_id"]),
                    ),
                    None,
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "renders",
                        "model_b_{}_fracture_view_v2.png".format(o["break_id"]),
                    ),
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "renders",
                        "model_b_{}_fracture_view_depth.npy".format(o["break_id"]),
                    ),
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "renders",
                        "model_b_{}_fracture_view.npz".format(o["break_id"]),
                    ),
                ]
            )

    if args.fast_dev_run:
        run(paths[0])
        exit(0)

    logging.info(f"Found {len(paths)} files")
    p = mp.Pool(args.num_workers)
    if not args.debug:
        random.shuffle(paths)
    for _ in tqdm.tqdm(p.imap_unordered(run, paths), total=len(paths)):
        pass
