import os
import logging
import argparse
import random
import math
import json

import utils


def split_train_test(object_list, train_ratio):
    """Train ratio in order train, val, test.
    Will split objects such that class distribution is preserved.
    """

    # Get object classes
    div_by_classes = {}
    for o in object_list:
        if o["class_id"] not in div_by_classes:
            div_by_classes[o["class_id"]] = []

        for d in div_by_classes[o["class_id"]]:
            if d[0]["instance_id"] == o["instance_id"]:
                d.append(o)
                break
        else:
            div_by_classes[o["class_id"]].append([o])

    # Cut each class
    train, test, val = [], [], []
    trainc, testc, valc = [], [], []
    for data in div_by_classes.values():
        random.shuffle(data)

        num_samples = len(data)
        tr_stop = int(math.ceil(num_samples * train_ratio[0]))
        val_stop = int(math.ceil(num_samples * (train_ratio[0] + train_ratio[1])))
        test_stop = num_samples

        if num_samples == 3:
            tr_stop, val_stop, test_stop = 1, 2, 3
        else:
            if val_stop >= test_stop:
                val_stop -= 1
            if tr_stop >= val_stop:
                tr_stop -= 1

        trainl = data[:tr_stop]
        testl = data[val_stop:]
        vall = data[tr_stop:val_stop]

        trainc.append(len(trainl))
        testc.append(len(testl))
        valc.append(len(vall))

        for o in trainl:
            train.extend(o)
        for o in testl:
            test.extend(o)
        for o in vall:
            val.extend(o)

    assert sum([len(train), len(test), len(val)]) == len(object_list)

    logging.info(f"Total objects: {len(object_list)}")
    logging.info(f"Train contains {len(train)} objects")
    classes = [o["class_id"] for o in train]
    for c in set(classes):
        logging.info(f"Train contains {classes.count(c)} objects from class {c}")
    logging.info(f"Test contains {len(test)} objects")
    classes = [o["class_id"] for o in test]
    for c in set(classes):
        logging.info(f"Test contains {classes.count(c)} objects from class {c}")
    logging.info(f"Val contains {len(val)} objects")
    classes = [o["class_id"] for o in val]
    for c in set(classes):
        logging.info(f"Val contains {classes.count(c)} objects from class {c}")

    return train, test, val


def find_objects(roots, num_breaks=10, unique=False):
    """Find fractured shapenet objects.
    roots argument needs to be a list of shapenet class directories.
    """

    object_list = []
    object_set = set()

    if not isinstance(roots, list):
        roots = [roots]

    for root in roots:
        # Needs to be a directory
        if not os.path.isdir(root):
            continue

        # Get the class id
        class_id = os.path.basename(root)

        for instance_id in os.listdir(root):
            # Give this object a unique id
            unique_id = class_id + instance_id

            # Needs to be a directory
            if not os.path.isdir(os.path.join(root, instance_id)):
                continue

            # Iterate over all breaks
            for bi in range(num_breaks):
                # Check to make sure all of these paths exist
                inputs = [
                    os.path.join(root, instance_id, "models", f"model_c.obj"),
                    os.path.join(root, instance_id, "models", f"model_b_{bi}.obj"),
                    os.path.join(root, instance_id, "models", f"model_r_{bi}.obj"),
                ]

                if all([os.path.exists(p) for p in inputs]) and (
                    unique_id not in object_set
                ):
                    if unique:
                        object_set.add(unique_id)
                    object_list.append(
                        {
                            "root": os.path.dirname(root),
                            "class_id": class_id,
                            "instance_id": instance_id,
                            "break_id": bi,
                        }
                    )

    return object_list


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Create a new splits file from one or more shapenet classes."
    )
    parser.add_argument("split", type=str, help="Name of the output splits file.")
    parser.add_argument(
        "roots",
        nargs="+",
        type=str,
        help="List of root directories. Has to be a shapenet class directory.",
    )
    parser.add_argument(
        "--num_breaks", type=int, default=10, help="Number of breaks to search for."
    )
    parser.add_argument(
        "--train_ratio",
        type=float,
        nargs=3,
        default=[0.7, 0.1, 0.2],
        help="Train, validation, test percent split.",
    )
    utils.add_common_args(parser)
    args = parser.parse_args()
    utils.configure_logging(args)

    object_list = find_objects(args.roots, num_breaks=args.num_breaks)

    if os.path.exists(args.split):
        input(f"File {args.split} already exists, do you really want to overwrite?")

    train, test, val = split_train_test(object_list, args.train_ratio)

    with open(args.split, "w+") as f:
        json.dump({"train": train, "test": test, "val": val}, f)
