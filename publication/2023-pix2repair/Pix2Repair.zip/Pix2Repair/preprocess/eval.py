import os
import logging
import argparse
import random
import multiprocessing as mp

import tqdm
import trimesh
import numpy as np

import utils


def run(path):
    f_in_r, f_out = path

    try:
        if os.path.exists(f_out) and not OVERWRITE:
            logging.debug(f"Skipped {f_in_r}")
            return
        logging.debug(f"Running {f_in_r}")

        mesh_r = trimesh.load(f_in_r)
        points, face_indices = mesh_r.sample(count=NUM_SAMPLES, return_index=True)
        normals = mesh_r.face_normals[face_indices, :]

        logging.debug(f"Saving {f_out}")
        np.savez(
            f_out,
            pts=points,
            normals=normals,
        )

    except Exception as e:
        if args.debug:
            raise e
        print(f"{e} error running {f_out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("split", type=str)
    parser.add_argument("--overwrite", action="store_true", default=False)
    parser.add_argument("--num_workers", type=int, default=mp.cpu_count() - 1)
    parser.add_argument("--num_samples", type=int, default=30_000)
    utils.add_common_args(parser)
    args = parser.parse_args()
    utils.configure_logging(args)

    if args.debug:
        args.num_workers = 1
    OVERWRITE = args.overwrite
    NUM_SAMPLES = args.num_samples

    split = utils.load_split(args.split)

    paths = []
    for s in ["test"]:
        for o in split[s]:
            paths.append(
                [
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "models",
                        "model_r_{}.obj".format(o["break_id"]),
                    ),
                    os.path.join(
                        o["root"],
                        o["class_id"],
                        o["instance_id"],
                        "models",
                        "model_r_{}_chamfer.npz".format(o["break_id"]),
                    ),
                ]
            )

    if args.fast_dev_run:
        run(paths[0])
        exit(0)

    logging.info(f"Found {len(paths)} files")
    p = mp.Pool(args.num_workers)
    if not args.debug:
        random.shuffle(paths)
    for _ in tqdm.tqdm(p.imap_unordered(run, paths), total=len(paths)):
        pass
