#!/bin/bash

# Make utils directory
mkdir -p utils

# Install inside mesh
cd utils &&
git clone https://github.com/nikwl/inside_mesh.git &&
cd inside_mesh &&
python setup.py build_ext --inplace &&
pip install .
