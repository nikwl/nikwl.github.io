import os
import yaml
import json
import argparse

import torch
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint
from pytorch_lightning.loggers import WandbLogger, TensorBoardLogger

import pix2repair.generate as generate
from pix2repair.trainer import Pix2RepairTrainer
from pix2repair.data import FractureDatamodule, dataset_resolver
from pix2repair.model import model_resolver
from pix2repair.config import default_config


def find_specs(path):
    """Find specs file during evaluation."""
    if os.path.splitext(path)[-1] == ".ckpt":
        path = os.path.dirname(os.path.dirname(path))
    path = os.path.realpath(os.path.join(path, "specs.yaml"))
    return path


def get_logdir(trainer):
    """Pytorch lightning provides no functionality to get logging directory.
    This is dumb.
    """
    try:
        return os.path.join(
            trainer.logger.save_dir, trainer.logger.name, trainer.logger.version
        )
    except TypeError:
        return trainer.logger.experiment.get_logdir()


def main(args):
    if args.test:
        # Infer the specs file from the passed path
        args.train = find_specs(args.test)

        print(f"Loading from {os.path.abspath(args.train)}")
        specs = yaml.safe_load(open(args.train, "r"))

        # ho boy this is janky
        if args.name is not None:
            if "threshold=" in args.name:
                specs["threshold"] = float(
                    args.name.split("threshold=")[-1].split(":")[0]
                )
                specs["test_generator_kwargs"]["threshold"] = float(
                    args.name.split("threshold=")[-1].split(":")[0]
                )
                specs["train_generator_kwargs"]["threshold"] = float(
                    args.name.split("threshold=")[-1].split(":")[0]
                )
                print("=OVERRIDING THRESHOLD {}".format(specs["threshold"]))
            if "resolution0=" in args.name:
                specs["test_generator_kwargs"]["resolution0"] = int(
                    args.name.split("resolution0=")[-1].split(":")[0]
                )
                specs["train_generator_kwargs"]["resolution0"] = int(
                    args.name.split("resolution0=")[-1].split(":")[0]
                )
                print(
                    "=OVERRIDING RESOLUTION0 {}".format(
                        specs["test_generator_kwargs"]["resolution0"]
                    )
                )

        # Update the loaded specs with defaults
        specs = default_config(specs)
        print("Specs loaded:\n", specs)

        # Initialize the model, just use the trainer to load
        model = Pix2RepairTrainer.load_from_checkpoint(
            args.test,
            model=model_resolver(specs, "network")(
                encoder=model_resolver(specs, "encoder"),
                decoder_c=model_resolver(specs, "decoder"),
                decoder_b=model_resolver(specs, "decoder"),
                z_dim=specs["z_dim"],
                c_dim=specs["c_dim"],
                pts_batch=specs["pts_batch"],
                normalize_points=specs["normalize_points"],
                enable_break_loss=specs["enable_break_loss"],
            ),
        )
        model = model.model

        # Load test data
        test_set = dataset_resolver(specs["dataset"])(
            roots=specs["data_root"],
            image_size=specs["image_size"],
            subsample=specs["point_subsample"],
            validate=specs["validate_data"],
            num_inputs=specs["num_inputs"],
            shuffle_fracture_view=specs["shuffle_fracture_view"],
            split="test",
        )

        # Create the output directory, where all the meshes will go
        logdir = os.path.dirname(args.train)
        exp_name = os.path.splitext(os.path.basename(args.test))[0]
        root_dir = os.path.join(logdir, exp_name + ":{}".format(args.name))

        # Create the mesh generator
        generator = generate.ShapeGenerator(
            root_dir=root_dir, **specs["test_generator_kwargs"]
        )

        taxonomy_data = json.load(open(specs["shapenet_taxonomy"]))
        generate.generate(
            model,
            generator,
            test_set,
            device="cuda",
            reconstruct_list=args.reconstruct_list,
        )
        if args.render:
            generate.render(generator, test_set)
        if args.eval:
            generate.evaluate(
                generator, test_set, taxonomy_data=taxonomy_data, skip_load=True
            )

    else:
        # If we were passed a checkpoint, load the saved specs
        if args.resume is not None:
            args.train = find_specs(args.resume)
            run_id = os.path.basename(os.path.dirname(args.train))

        print(f"Loading from {os.path.abspath(args.train)}")
        specs = yaml.safe_load(open(args.train, "r"))

        # Update the loaded specs with defaults
        specs = default_config(specs)
        print("Specs loaded:\n", specs)

        # Seed pytorch lightning
        pl.seed_everything(specs["seed"])

        # Setup your dataloaders
        data_module = FractureDatamodule(
            randomize_num_inputs=specs["randomize_num_inputs"],
            dataset_module=dataset_resolver(specs["dataset"]),
            dataset_kwargs=dict(
                roots=specs["data_root"],
                image_size=specs["image_size"],
                subsample=specs["point_subsample"],
                vox_subsample=specs["vox_subsample"],
                validate=specs["validate_data"],
                num_inputs=specs["num_inputs"],
                shuffle_fracture_view=specs["shuffle_fracture_view"],
            ),
            dataloader_kwargs=dict(
                num_workers=args.num_workers,
                batch_size=specs["batch_size"],
                persistent_workers=torch.cuda.device_count() > 1,
            ),
        )
        data_module.setup("fit")

        # Initialize the model
        model = Pix2RepairTrainer(
            model=model_resolver(specs, "network")(
                encoder=model_resolver(specs, "encoder"),
                decoder_c=model_resolver(specs, "decoder"),
                decoder_b=model_resolver(specs, "decoder"),
                z_dim=specs["z_dim"],
                c_dim=specs["c_dim"],
                pts_batch=specs["pts_batch"],
                normalize_points=specs["normalize_points"],
                enable_break_loss=specs["enable_break_loss"],
            ),
            lr=specs["lr"],
            betas=(specs["beta1"], specs["beta2"]),
            generator=generate.ShapeGenerator(**specs["train_generator_kwargs"]),
            data_module=data_module,
            generate_num=specs["generate_num"],
            specs=specs,
        )

        # Set up logging
        logger = None
        if specs["wandb_user"] is not None: 
            print("Using wandb logger")
            if args.resume is not None:
                logger = WandbLogger(
                    project=specs["wandb_project"],
                    entity=specs["wandb_user"],
                    resume=True,
                    id=run_id,
                )
            else:
                logger = WandbLogger(
                    project=specs["wandb_project"],
                    entity=specs["wandb_user"],
                )
            logger.experiment.config.update(specs)
            logger.experiment.config.update(
                {
                    "train_instances": len(data_module.train_set),
                    "val_instances": len(data_module.val_set),
                }
            )
        else:
            print("Using tensorboard logger")
            logger = TensorBoardLogger("experiments")

        # Train!
        pl_module = pl.Trainer(
            auto_lr_find=(specs["lr"] == "auto"),
            max_epochs=specs["num_epochs"],
            accelerator="auto",
            logger=logger,
            log_every_n_steps=min(50, len(data_module.val_set) // specs["batch_size"]),
            check_val_every_n_epoch=specs["log_every"],
            reload_dataloaders_every_n_epochs=False,
            default_root_dir="experiments",
            callbacks=[
                ModelCheckpoint(  # Save every 20 epochs
                    save_top_k=-1,
                    every_n_epochs=specs["log_every"],
                    filename="{epoch}",
                )
            ],
        )

        try:
            logdir = get_logdir(pl_module)
            if not os.path.isdir(logdir):
                os.mkdir(logdir)
            print(f"Logging to: {logdir}")

            # Copy the specs file
            with open(os.path.join(logdir, "specs.yaml"), "w+") as f:
                yaml.dump(specs, f, allow_unicode=True)
        except TypeError:
            print("WARNING: Could not copy specs file.")

        if (specs["lr"] == "auto") and (args.resume is None):
            pl_module.tune(
                model=model,
                datamodule=data_module,
            )

        pl_module.fit(
            model=model,
            ckpt_path=args.resume,
            datamodule=data_module,
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument(
        "--train",
        type=str,
        default=None,
        help="Start training from a specs file.",
    )
    parser.add_argument(
        "--resume",
        type=str,
        default=None,
        help="Resume training from a checkpoint file.",
    )
    parser.add_argument(
        "--test",
        type=str,
        default="",
        help="Test from a checkpoint file.",
    )
    parser.add_argument(
        "--num_workers",
        type=int,
        default=4,
        help="How many dataloader workers.",
    )
    parser.add_argument(
        "--name",
        type=str,
        default="",
        help="Give this experiment a custom name.",
    )
    parser.add_argument(
        "--eval",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--render",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--reconstruct_list",
        type=int,
        default=None,
        nargs="+",
    )
    args = parser.parse_args()
    assert not (
        args.train is None and args.resume is None and args.test is None
    ), "Must specify train, resume, or test."

    main(args)
