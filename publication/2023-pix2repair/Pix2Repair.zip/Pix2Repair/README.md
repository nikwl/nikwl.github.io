# Pix2Repair

Code for "Pix2Repair: Implicit Shape Restoration from Images"

## Installation

Code tested using Ubuntu 22.04 and python 3.9.16. Note that you need to have the following apt dependencies installed.

```bash
sudo apt-get install freeglut3-dev
```

We recommend using virtualenv. The following snippet will create a new virtual environment, activate it, and install dependencies.

```bash
sudo apt-get install virtualenv && \
virtualenv -p python3.9 env && \
source setup.bash && \
pip install -r requirements.txt && \
./install.bash
```

## Training

Download the data from [DeepJoin](https://terascale-all-sensing-research-studio.github.io/DeepJoin/)

Set the DATA_ROOT environment variable to the downloaded folder location
```
export DATA_ROOT=/path/to/data/GeometricBreaks
```

Create a new specs file from one of the existing templates. Templates can be found in `specs`. Perform training by passing the path to a specs file.
```bash
python main.py --train specs/pix2repair_all.yaml
```

## Testing

Download trained weights.
```bash
pip install gdown
./download_weights.sh
```

Perform evaluation by passing the test flag with the path to a specific checkpoint.
```bash
python main.py --test experiments/pix2repair_all/checkpoints/epoch=599.ckpt
```
