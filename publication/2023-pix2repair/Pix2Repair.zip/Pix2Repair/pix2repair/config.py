def default_config(specs):
    """Load config defaults."""

    default_specs = {
        "exp_name": "test",
        "wandb_project": None,
        "wandb_user": None,
        "data_root": "",
        "validate_data": True,
        "seed": 9999,
        "num_epochs": 1000,  # Num epochs to train for
        "batch_size": 8,  # Batch size during training
        "num_inputs": 3,  # If using multiview, how many images?
        "randomize_num_inputs": False,
        "point_subsample": 8192,
        "point_subsample_method": "smart",
        "vox_subsample": 65536,
        "c_dim": 512,  # Size of conditional network input
        "z_dim": 0,  # Size of z latent vector (i.e. size of generator input)
        "image_size": 224,
        "lr": 2.75e-05,  # Learning rate for optimizers
        "beta1": 0.9,  # Beta1 hyperparam for Adam optimizers
        "beta2": 0.999,  # Beta2 hyperparam for Adam optimizers
        "shapenet_taxonomy": "splits/shapenet.json",
        "generate_num": 4,  # How many meshes to generate during validation
        "pts_batch": 2**18,  # Max points that can be passed to the gpu
        "threshold": 0.05,  # Isosurface threshold
        "log_every": 20, # Log every n epochs
        "padding": 0.05,
        "dataset": "FractureDataset",
        "point_scale": 1.0,
        "point_z_offset": 0.0,
        "normalize_points": False,
        "shuffle_fracture_view": False,
        "enable_break_loss": True,
        "test_generator_kwargs": {
            "use_mise": False,
            "resolution0": 128,
            "upsampling_steps": 0,
            "padding": "*padding",
            "threshold": "*threshold",
            "point_scale": "*point_scale",
            "point_z_offset": "*point_z_offset",
        },
        "train_generator_kwargs": {
            "use_mise": False,
            "resolution0": 64,
            "upsampling_steps": 0,
            "padding": "*padding",
            "threshold": "*threshold",
            "point_scale": "*point_scale",
            "point_z_offset": "*point_z_offset",
        },
        "network_arch": "Pix2Repair",
        "encoder_arch": "Resnet18",
        "encoder_kwargs": {
            "c_dim": "*c_dim",  # Use yaml addressing
            "normalize": True,
            "use_linear": True,
            "weights": "ResNet18_Weights.IMAGENET1K_V1",  # This is imported from torchvision.models
        },
        "decoder_arch": "DecoderCBatchNorm2",
        "decoder_kwargs": {
            "dim": 3,
            "z_dim": "*z_dim",
            "c_dim": "*c_dim",
            "hidden_size": 256,
            "n_blocks": 5,
            "leaky": False,
        },
    }

    keydiff = set(specs.keys()).difference(set(default_specs.keys()))
    assert len(keydiff) == 0, f"Unrecognized keys {keydiff}"

    default_specs.update(specs)

    def resolve_references(root_d, d):
        """Recursively traverse the dictionary, replacing * references"""
        for k, i in d.items():
            if isinstance(i, str) and i[0] == "*":
                d[k] = root_d[i[1:]]
            if isinstance(i, dict):
                resolve_references(root_d, i)

    resolve_references(default_specs, default_specs)

    return default_specs
