import trimesh
import numpy as np
import torchmetrics
from scipy.spatial import cKDTree as KDTree


def get_symmetric_transform(
    gt_shape, pred_shape, planes, num_mesh_samples=30000, use_one_sided=False
):
    """Return the rotation around the y axis to minimize the chamfer

    Planes determines the type of symmetry.
    -1: axially symmetric (vase)
    1: planar symmetry (rectangular table)
    2: 2-way planar symmetry (square table)
    """

    assert planes in [-1, 1, 2]

    if planes == -1:
        num_rotations = 36
    elif planes == 1:
        num_rotations = 2
    elif planes == 2:
        num_rotations = 4
    y_rots = np.linspace(0, 2 * np.pi, num_rotations, endpoint=False)

    chamfers = []
    transforms = []
    for y_rot in y_rots:
        pred_shape_copy = pred_shape.copy()
        mat = trimesh.transformations.rotation_matrix(y_rot, [0, 1, 0])
        pred_shape_copy.apply_transform(mat)

        if use_one_sided:
            dist = one_sided_chamfer(gt_shape, pred_shape_copy, num_mesh_samples)
        else:
            dist = chamfer(gt_shape, pred_shape_copy, num_mesh_samples)

        transforms.append(mat)
        chamfers.append(dist)

    return transforms[np.argmin(chamfers)], np.min(chamfers)


def chamfer(gt_shape, pred_shape, num_mesh_samples=30000):
    """
    Compute the chamfer distance for two 3D meshes.
    This function computes a symmetric chamfer distance, i.e. the mean chamfers.
    Based on the code provided by DeepSDF.
    Args:
        gt_shape (trimesh object or points): Ground truth shape.
        pred_shape (trimesh object or points): Predicted shape.
        num_mesh_samples (points): Number of points to sample from the predicted
            shape. Must be the same number of points as were computed for the
            ground truth shape.
    """

    try:
        gt_pts = trimesh.sample.sample_surface(gt_shape, num_mesh_samples)[0]
        assert gt_shape.vertices.shape[0] != 0, "gt shape has no vertices"
    except AttributeError:
        gt_pts = gt_shape
        assert (
            gt_pts.shape[0] == num_mesh_samples
        ), "Wrong number of gt points, expected {} got {}".format(
            num_mesh_samples, gt_pts.shape[0]
        )
    try:
        pred_pts = trimesh.sample.sample_surface(pred_shape, num_mesh_samples)[0]
    except AttributeError:
        pred_pts = pred_shape
        assert (
            pred_pts.shape[0] == num_mesh_samples
        ), "Wrong number of points, expected {} got {}".format(
            num_mesh_samples, pred_pts.shape[0]
        )

    # one direction
    one_distances, _ = KDTree(pred_pts).query(gt_pts)
    gt_to_pred_chamfer = np.mean(np.square(one_distances))

    # other direction
    two_distances, _ = KDTree(gt_pts).query(pred_pts)
    pred_to_gt_chamfer = np.mean(np.square(two_distances))

    return gt_to_pred_chamfer + pred_to_gt_chamfer


def one_sided_chamfer(gt_shape, pred_shape, num_mesh_samples=30000):
    """
    Compute the chamfer distance for two 3D meshes.
    This function computes a one-sided chamfer distance, i.e. the chamfer distance
    from the every point in the predicted shape to the ground truth.
    Based on the code provided by DeepSDF.
    Args:
        gt_shape (trimesh object or points): Ground truth shape.
        pred_shape (trimesh object or points): Predicted shape.
        num_mesh_samples (points): Number of points to sample from the predicted
            shape. Must be the same number of points as were computed for the
            ground truth shape.
    """

    try:
        gt_pts = trimesh.sample.sample_surface(gt_shape, num_mesh_samples)[0]
        assert gt_shape.vertices.shape[0] != 0, "gt shape has no vertices"
    except AttributeError:
        gt_pts = gt_shape
        assert (
            gt_pts.shape[0] == num_mesh_samples
        ), "Wrong number of points, expected {} got {}".format(
            num_mesh_samples, gt_pts.shape[0]
        )
    try:
        pred_pts = trimesh.sample.sample_surface(pred_shape, num_mesh_samples)[0]
    except AttributeError:
        pred_pts = pred_shape
        assert (
            pred_pts.shape[0] == num_mesh_samples
        ), "Wrong number of points, expected {} got {}".format(
            num_mesh_samples, pred_pts.shape[0]
        )

    # other direction
    two_distances, _ = KDTree(gt_pts).query(pred_pts)
    pred_to_gt_chamfer = np.mean(np.square(two_distances))

    return pred_to_gt_chamfer * 2


def normals_correctness(gt_shape, pred_shape, num_mesh_samples=30000):
    def distance_p2p(points_src, normals_src, points_tgt, normals_tgt):
        """Computes minimal distances of each point in points_src to points_tgt.
        Args:
            points_src (numpy array): source points
            normals_src (numpy array): source normals
            points_tgt (numpy array): target points
            normals_tgt (numpy array): target normals
        i.e. the target points get queried
        """

        kdtree = KDTree(points_tgt)
        dist, idx = kdtree.query(points_src)

        if normals_src is not None and normals_tgt is not None:
            # normals_src = \
            #     normals_src / np.linalg.norm(normals_src, axis=-1, keepdims=True)
            # normals_tgt = \
            #     normals_tgt / np.linalg.norm(normals_tgt, axis=-1, keepdims=True)

            # Exclude normals that are all zero (happens for some shapenet models)
            normals_src = normals_src[np.linalg.norm(normals_src, axis=-1) > 0, :]
            normals_tgt = normals_tgt[np.linalg.norm(normals_tgt, axis=-1) > 0, :]

            normals_dot_product = (normals_tgt[idx] * normals_src).sum(axis=-1)
            # Handle normals that point into wrong direction gracefully
            # (mostly due to mehtod not caring about this in generation)
            normals_dot_product = np.abs(normals_dot_product)
        else:
            normals_dot_product = np.array(
                [np.nan] * points_src.shape[0], dtype=np.float32
            )
        return dist, normals_dot_product

    obj_tgt, obj_src = gt_shape, pred_shape

    try:
        points_src, face_indices_src = obj_src.sample(
            count=num_mesh_samples, return_index=True
        )
        points_tgt, face_indices_tgt = obj_tgt.sample(
            count=num_mesh_samples, return_index=True
        )

        normals_src = obj_src.face_normals[face_indices_src, :]
        normals_tgt = obj_tgt.face_normals[face_indices_tgt, :]
    except AttributeError:
        points_src, normals_src = obj_src
        points_tgt, normals_tgt = obj_tgt

    _, accuracy_normals = distance_p2p(points_src, normals_src, points_tgt, normals_tgt)
    accuracy_normals = accuracy_normals.mean()

    _, completeness_normals = distance_p2p(
        points_tgt, normals_tgt, points_src, normals_src
    )
    completeness_normals = completeness_normals.mean()

    normals_correctness = 0.5 * completeness_normals + 0.5 * accuracy_normals

    return normals_correctness, completeness_normals, accuracy_normals


def iou(x, y):
    """Intersection over union of two boolean arrays. Takes tensors"""
    i = (x * y).sum() / (x.sum() + y.sum())
    if i.isnan():
        i = 0
    return i


def tpr_tnr(x, y):
    """True negative rate and true positive rate. Takes tensors"""

    tn, fp, fn, tp = torchmetrics.functional.confusion_matrix(
        x,
        y,
        task="binary",
    ).ravel()

    tpr = tp / (tp + fn)
    if tpr.isnan():
        tpr = 0
    tnr = tn / (tn + fp)
    if tnr.isnan():
        tnr = 0

    return tpr, tnr
