import os
import time
import random
import tempfile
import multiprocessing as mp
from collections import defaultdict

import tqdm
import torch
import skimage
import trimesh
import numpy as np
import pandas as pd
from PIL import Image

from pix2repair.data import uniform_sample_points
from pix2repair import utils
import pix2repair.vis as vis
import pix2repair.metrics as metrics


QUEUE = mp.Queue()


class ShapeGenerator:
    def __init__(
        self,
        root_dir=None,
        resolution0=128,
        use_mise=False,
        upsampling_steps=0,
        threshold=0.5,
        padding=0.1,
        point_scale=1.0,
        point_z_offset=0,
    ):
        self._root_dir = root_dir
        self.resolution0 = resolution0
        self.use_mise = use_mise
        self.upsampling_steps = upsampling_steps
        self.threshold = threshold
        self.padding = padding
        self.point_scale = point_scale
        self.point_z_offset = point_z_offset

        assert not use_mise

        self.box_size = 1 + self.padding * 2

        self.tf = trimesh.transformations.scale_matrix(
            self.point_scale
        ) @ trimesh.transformations.translation_matrix([0, 0, self.point_z_offset])

        self._points = uniform_sample_points(self.resolution0, padding).astype(
            np.float32
        )
        self._points = (self.tf[:3, :3] @ self._points.T).T
        self._points = self._points + self.tf[:3, 3]
        self._points = torch.from_numpy(self._points).float()
        self._points.requires_grad = False

    @property
    def points(self):
        return self._points.clone()

    def root_dir(self, create=True):
        """Return root generation dir"""
        if not os.path.isdir(self._root_dir) and create:
            os.mkdir(self._root_dir)
        return self._root_dir

    def mesh_dir(self, create=True):
        """Return mesh dir"""
        root_dir = self.root_dir(create)
        mesh_dir = os.path.join(root_dir, "meshes")
        if not os.path.isdir(mesh_dir) and create:
            os.mkdir(mesh_dir)
        return mesh_dir

    def get_render_lock(self):
        suffix = ".render_lock"
        fs = [
            f
            for f in os.listdir(os.path.dirname(self.mesh_dir()))
            if os.path.splitext(f)[-1] == suffix
        ]
        if len(fs) != 0:
            return False
        self.tf = tempfile.NamedTemporaryFile(
            mode="w", dir=os.path.dirname(self.mesh_dir()), suffix=suffix
        )
        return True

    def get_eval_lock(self):
        suffix = ".eval_lock"
        fs = [
            f
            for f in os.listdir(os.path.dirname(self.mesh_dir()))
            if os.path.splitext(f)[-1] == suffix
        ]
        if len(fs) != 0:
            return False
        self.tf = tempfile.NamedTemporaryFile(
            mode="w", dir=os.path.dirname(self.mesh_dir()), suffix=suffix
        )
        return True

    def path_render(self):
        return os.path.join(os.path.dirname(self.mesh_dir()), "summary.png")

    def path_metrics_csv(self):
        return os.path.join(os.path.dirname(self.mesh_dir()), "metrics.csv")

    def path_timing(self):
        return os.path.join(os.path.dirname(self.mesh_dir()), "timing.npz")

    def path_matrices(self):
        return os.path.join(os.path.dirname(self.mesh_dir()), "matrices.npy")

    def path_mesh(self, idx, shape, create=True):
        return os.path.join(self.mesh_dir(create), f"{idx}_{shape}.ply")

    def path_mesh_render(self, idx, create=True):
        return os.path.join(self.mesh_dir(create), f"{idx}.png")

    def forward(self, model, points, inputs, return_scores=False):
        """Model forward passthrough"""

        occ_c, occ_b, occ_r = model.forward(points, inputs)

        return (
            occ_c.detach().cpu().numpy(),
            occ_b.detach().cpu().numpy(),
            occ_r.detach().cpu().numpy(),
        )

    def mesh_from_occ(self, occ):
        """Generate a mesh from logits"""

        # Compute the output resolution
        res = self.resolution0 * (2**self.upsampling_steps)

        # Reshape input
        occ = occ.reshape((res, res, res))
        n_x, n_y, n_z = occ.shape

        # Make sure that mesh is watertight
        occ = np.pad(occ, 1, "constant", constant_values=-1e6)

        try:
            vertices, faces, _, _ = skimage.measure.marching_cubes(
                occ,
                level=self.threshold,
                gradient_direction="descent",
            )

            # Undo the offset introduced by np.pad
            vertices -= 1

            # Normalize to bounding box
            vertices /= np.array([n_x - 1, n_y - 1, n_z - 1])
            vertices = self.box_size * (vertices - 0.5)

            # x and y are transposed
            vertices[:, [0, 1, 2]] = vertices[:, [1, 0, 2]]

            mesh = trimesh.Trimesh(vertices, faces)

            # Apply the point transform (this accounts for scaling in front of the camera)
            mesh.apply_transform(self.tf)
        except ValueError:
            mesh = trimesh.Trimesh()

        return mesh

    def render_from_mesh(self, mesh, res=(224, 224)):
        """Generate a render of a mesh"""
        try:
            img = utils.render(
                mesh,
                resolution=res[:2],
                xtrans=0.0,
                ytrans=0.0,
                ztrans=2.0,
                xrot=-25.0,
                yrot=-45.0,
                zrot=0.0,
            )
        except ValueError:
            img = np.ones((res[0], res[1], 3), dtype=np.uint8) * 255
        return img


def eval(inputs):
    idx, class_id, pred_path, gt = inputs

    gt_data = np.load(gt)
    gt_pts = gt_data["pts"]
    gt_normals = gt_data["normals"]

    num_mesh_samples = len(gt_pts)
    chamfer = np.nan
    symmetric_chamfer = np.nan
    normal_consistency = np.nan
    mat = np.eye(4)
    try:
        # Compute sample points ahead of time
        pred = utils.trimesh_force(trimesh.load(pred_path))
        pred_pts, face_inds = trimesh.sample.sample_surface(pred, num_mesh_samples)
        pred_normals = pred.face_normals[face_inds, :]

        # Compute chamfer distance
        chamfer = metrics.chamfer(gt_pts, pred_pts)

        # Compute symmetric chamfer distance
        planes = None
        if class_id in ["03593526", "02876657", "03797390"]:  # bottles, jars, and mugs
            planes = -1
        elif class_id in ["04379243"]:  # tables
            planes = 2

        if planes is not None:
            mat, symmetric_chamfer = metrics.get_symmetric_transform(
                gt_pts, pred, planes, num_mesh_samples
            )
        else:
            symmetric_chamfer = chamfer

        # Transform the model by the symmetric transform
        pred.apply_transform(mat)

        # Get the normal consistency
        normal_consistency, _, _ = metrics.normals_correctness(
            [gt_pts, gt_normals], [pred_pts, pred_normals], mat
        )

    except (ValueError, IndexError):
        pass

    QUEUE.put(
        {
            "idx": idx,
            "chamfer": chamfer,
            "mat": mat,
            "symmetric_chamfer": symmetric_chamfer,
            "normal_consistency": normal_consistency,
        }
    )


def evaluate(
    generator,
    loader,
    skip_load=False,
    num_workers=os.cpu_count() - 1,
    taxonomy_data={},
):
    # Create the meshes directory
    mesh_dir = generator.mesh_dir()
    path_metrics = generator.path_metrics_csv()
    print(f"Saving meshes to: {mesh_dir}")
    print("Starting mesh evaluation...")

    # if not generator.get_eval_lock():
    #     print("Another process was evaluating, exiting")
    #     exit()

    if os.path.exists(path_metrics) and not skip_load:
        print(f"Loading from {path_metrics}")
        metrics_df = pd.read_csv(path_metrics)

    else:
        # Create a list of all the inputs
        inputs = []
        for idx in range(len(loader)):
            class_id = loader.get(idx, type="metadata")["class_id"]
            if os.path.exists(generator.path_mesh(idx, "r")):
                inputs.append(
                    [
                        idx,  # index
                        class_id,
                        generator.path_mesh(idx, "r"),  # Pred mesh path
                        loader.get(idx, "r", type="chamfer"),  # gt points path
                    ]
                )

        # Spin up a pool to generate the results
        p = mp.Pool(num_workers)
        for _ in tqdm.tqdm(p.imap_unordered(eval, inputs), total=len(inputs)):
            pass

        # Collect the data
        inds_values = []
        for _ in range(QUEUE.qsize()):
            inds_values.append(QUEUE.get())
        inds_values = sorted(inds_values, key=lambda x: x["idx"])  # Sort by index

        # Save the matrices
        matrices = [np.eye(4) for _ in range(len(loader))]
        for item in inds_values:
            idx = item["idx"]
            matrices[idx] = item["mat"]
        np.save(generator.path_matrices(), matrices)

        # Create a dataframe with all the results, and class and instance info
        df = defaultdict(lambda: [np.nan] * len(loader))
        for item in inds_values:
            idx = item["idx"]

            class_id = loader.get(idx, type="metadata")["class_id"]
            instance_id = loader.get(idx, type="metadata")["instance_id"]

            df["chamfer"][idx] = item["chamfer"]
            df["symmetric_chamfer"][idx] = item["symmetric_chamfer"]
            df["normal_consistency"][idx] = item["normal_consistency"]

            df["class_id"][idx] = taxonomy_data.get(class_id, class_id)
            df["instance_id"][idx] = instance_id

        metrics_df = pd.DataFrame(dict(df))

        print(f"Saving metrics to: {path_metrics}")
        metrics_df.to_csv(path_metrics)

    # Print out the evaluation
    metric_names = [
        "emd",
        "chamfer",
        "symmetric_chamfer",
        "normal_consistency",
    ]
    data_means = []
    data_names = []
    for m in metric_names:
        # Summary results about a given metric
        try:
            print(
                "{} Mean: {:.5f}, Percent Generated: {:.5f}, Generated {}, Total: {}".format(
                    m,
                    metrics_df[m].mean(),
                    1 - metrics_df[m].isna().sum() / metrics_df[m].size,
                    metrics_df[m].size - metrics_df[m].isna().sum(),
                    metrics_df[m].size,
                )
            )
        except KeyError:
            continue

        # Group the metric by class
        data_means.append(metrics_df.groupby("class_id")[m].mean())
        data_names.append(m)

    # Compute class percent generated
    grouped_nans = metrics_df["chamfer"].isna().groupby(metrics_df["class_id"])
    data_percent_generated = 1 - grouped_nans.sum() / grouped_nans.size()

    # Assemble the final dataframe, all of the metrics by class and generated
    mean_and_generated = pd.concat(data_means + [data_percent_generated], axis=1)
    mean_and_generated.columns = data_names + ["percent_generated"]

    print(mean_and_generated)


def rend(inputs):
    idx, f_out, image, pred_c, pred_r, gt_c, gt_b, gt_r, render_complete = inputs

    if os.path.exists(f_out):
        render_list = np.array(Image.open(f_out))
        QUEUE.put((idx, render_list))
        return

    image = np.array(Image.open(image))
    try:
        if render_complete:
            pred_c = utils.trimesh_force(trimesh.load(pred_c))
            pred_c = trimesh.Trimesh(pred_c.vertices, pred_c.faces)  # Remove texture
        pred_r = utils.trimesh_force(trimesh.load(pred_r))
    except ValueError:
        # raise
        return

    # Load complete
    try:
        gt_c = utils.trimesh_force(trimesh.load(gt_c))
        gt_c = trimesh.Trimesh(gt_c.vertices, gt_c.faces)  # Remove texture
    except ValueError:
        render_complete = False

    # Load ground truths
    gt_b = utils.trimesh_force(trimesh.load(gt_b))
    gt_r = utils.trimesh_force(trimesh.load(gt_r))

    # Recolor the meshes
    pred_r = vis.colorize_shape(pred_r, "r")
    gt_r = vis.colorize_shape(gt_r, "r")

    def try_render(mesh, resolution=(224, 224)):
        """Try and render a mesh. It might fail if the mesh is invalid."""
        try:
            return utils.render(
                mesh,
                resolution=resolution,
                xtrans=0.0,
                ytrans=0.0,
                ztrans=2.0,
                xrot=-25.0,
                yrot=-45.0,
                zrot=0.0,
            )
        except ValueError:
            return np.ones((resolution[0], resolution[1], 3), dtype=np.uint8) * 255

    render_list = []

    render_list.append(vis.annotate_image(image, str(idx)))

    if render_complete:
        render_list.append(try_render(pred_c))
        render_list.append(try_render(gt_c))

    render_list.append(try_render(pred_r))
    render_list.append(try_render(gt_r))

    render_list.append(try_render([gt_b, pred_r]))
    render_list.append(try_render([gt_b, gt_r]))

    # Stack the renders together
    render_list = np.hstack(render_list)
    Image.fromarray(render_list).save(f_out)

    QUEUE.put((idx, render_list))


def render(
    generator,
    loader,
    render_complete=True,
    num_workers=os.cpu_count() - 1,
):
    # Create the meshes directory
    mesh_dir = generator.mesh_dir()
    print(f"Saving meshes to: {mesh_dir}")
    print("Starting mesh renderer...")

    # if not generator.get_render_lock():
    #     print("Another process was rendering, exiting")
    #     exit()

    # Define some paths of summary metrics/images/etc
    path_render = generator.path_render()

    if os.path.exists(path_render):
        print(f"Render already exists: {path_render}")
        return

    # Create a list of all the inputs
    inputs = []
    for idx in range(len(loader)):
        inputs.append(
            [
                idx,  # index
                generator.path_mesh_render(idx),
                loader.get(idx, type="image"),
                generator.path_mesh(idx, "c"),  # Pred mesh path
                generator.path_mesh(idx, "r"),  # Pred mesh path
                loader.get(idx, "c", type="mesh"),
                loader.get(idx, "b", type="mesh"),
                loader.get(idx, "r", type="mesh"),
                render_complete,
            ]
        )

    # Spin up a pool to generate the results
    p = mp.Pool(num_workers)
    for _ in tqdm.tqdm(p.imap_unordered(rend, inputs), total=len(inputs)):
        pass

    # Collect the data
    inds_data = []
    for _ in range(QUEUE.qsize()):
        inds_data.append(QUEUE.get())
    inds_data = sorted(inds_data, key=lambda x: x[0])  # Sort by index
    row_stacker = [d[1] for d in inds_data]  # Throw out indices

    # Save image
    size = row_stacker[-1].shape
    row_stacker = np.vstack(row_stacker)
    while row_stacker.shape[0] > row_stacker.shape[1]:
        row_stacker = vis.vcutstack(row_stacker, size)
    print("Saving summary render to: " + path_render)
    vis.save_image_block(row_stacker, path_render)


def generate(
    model,
    generator,
    loader,
    randomize=True,
    device="cuda",
    reconstruct_list=None,
):
    # Create the meshes directory
    mesh_dir = generator.mesh_dir()
    print(f"Saving meshes to: {mesh_dir}")
    print("Starting mesh generation...")

    path_timing = generator.path_timing()

    # This is very important
    model.to(device)
    model.eval()

    # Points are static
    points = generator.points.unsqueeze(0)

    # Quick check set for skipping already generated meshes
    q_check = set([os.path.join(mesh_dir, p) for p in os.listdir(mesh_dir)])

    # Get inputs to reconstruct
    if reconstruct_list is None:
        reconstruct_list = list(range(len(loader)))
    if randomize:
        random.shuffle(reconstruct_list)

    timing_dict = defaultdict(list)
    pbar = tqdm.tqdm(reconstruct_list)
    for idx in pbar:
        # If the restoration mesh exists, then don't generate this mesh.
        path_pred_r = generator.path_mesh(idx, "r")

        if path_pred_r in q_check:
            continue
        if os.path.exists(path_pred_r):
            continue

        # Create batched input images
        batch = loader[idx]
        inputs = torch.from_numpy(batch["inputs"]).unsqueeze(0)

        # Fwd pass
        t0 = time.time()
        with torch.no_grad():
            occ_c, occ_b, occ_r = generator.forward(model, points, inputs)
        timing_dict["Forward Pass"].append(time.time() - t0)

        # Generate a mesh for each shape
        meshes = {}
        for shape, occ in zip(["c", "r"], [occ_c, occ_r]):
            occ = occ.squeeze()  # Unbatch input

            # Generate the mesh
            t0 = time.time()
            meshes[shape] = generator.mesh_from_occ(occ)
            meshes[shape].apply_transform(loader.shape_pose(idx))
            vis.colorize_shape(meshes[shape], shape)
            timing_dict["Mesh Generation"].append(time.time() - t0)

            # Save the mesh
            t0 = time.time()
            meshes[shape].export(generator.path_mesh(idx, shape))
            timing_dict["IO"].append(time.time() - t0)

    print("Timing_dict: ")
    for k, i in timing_dict.items():
        print(f"{k} took {np.array(i).mean()}")
    np.savez(path_timing, path_timing)
