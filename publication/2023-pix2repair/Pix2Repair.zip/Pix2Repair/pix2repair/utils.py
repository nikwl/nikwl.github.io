import os
import logging

import trimesh
import numpy as np
from PIL import Image

import pyrender
os.environ["PYOPENGL_PLATFORM"] = "egl"


def trimesh_force(mesh):
    """Convert a trimesh scene into a mesh"""

    if isinstance(mesh, list):
        return [trimesh_force(m) for m in mesh]

    if isinstance(mesh, trimesh.Scene):
        if len(mesh.geometry) == 0:
            mesh = trimesh.Trimesh()
        else:
            mesh = trimesh.util.concatenate(
                tuple(
                    trimesh.Trimesh(vertices=g.vertices, faces=g.faces)
                    if hasattr(g, "visual")
                    else trimesh.Trimesh(
                        vertices=g.vertices, faces=g.faces, visual=g.visual
                    )
                    for g in mesh.geometry.values()
                )
            )

    return mesh


def _is_sized(mesh):
    """Check if the model might be too large to be viewable in the renderer"""
    if not isinstance(mesh, list):
        mesh = [mesh]
    vertices = np.vstack(
        [
            m.vertices
            if isinstance(m, trimesh.PointCloud) or isinstance(m, trimesh.Trimesh)
            else m
            for m in trimesh_force(mesh)
        ]
    )
    max_ptp = max(vertices.ptp(axis=0))
    if max_ptp > 100:
        logging.warn(
            "Max PTP value of {} is unlikely to be viewable, try scaling your model down".format(
                max_ptp
            )
        )
        return False
    return True


def render(
    mesh,
    modality="color",
    fov=(np.pi / 4.0),
    resolution=(1280, 720),
    xtrans=0.0,
    ytrans=0.0,
    ztrans=2.0,
    xrot=-25.0,
    yrot=45.0,
    zrot=0.0,
    camera_pose=None,
    spotlight_intensity=8.0,
    remove_texture=False,
    wireframe=False,
    bg_color=255,
    mode="RGB",
    point_size=5,
    **kwargs,
):
    """Render a trimesh object or list of objects"""

    assert modality in ["color", "depth"]

    # Create a pyrender scene with ambient light
    scene = pyrender.Scene(ambient_light=np.ones(3), bg_color=bg_color, **kwargs)

    # Convert all scenes to meshes
    mesh = trimesh_force(mesh)

    # Check if the model is likely to be the correct size
    _is_sized(mesh)

    # Convert inputs to lists if necessary
    if not isinstance(mesh, list):
        mesh = [mesh]
    if not isinstance(wireframe, list):
        wireframe = [wireframe] * len(mesh)

    # Strip texture out of meshes
    if remove_texture:
        for i in range(len(mesh)):
            if isinstance(mesh[i], trimesh.Trimesh):
                mesh[i] = trimesh.Trimesh(
                    vertices=mesh[i].vertices, faces=mesh[i].faces
                )

    # Convert the input meshes into pyrender meshes
    for m, w in zip(mesh, wireframe):
        if isinstance(m, trimesh.points.PointCloud):
            logging.debug("Parsed pointcloud")
            if m.colors.shape[0] == 0:
                colors = np.array((0, 0, 0, 0))
            else:
                colors = m.colors
            scene.add(pyrender.Mesh.from_points(m.vertices, colors=colors))
        elif isinstance(m, trimesh.Trimesh):
            logging.debug("Parsed mesh")
            scene.add(pyrender.Mesh.from_trimesh(m, wireframe=w))
        else:
            logging.debug("Parsed vertex set")
            scene.add(pyrender.Mesh.from_points(m, colors=colors))

    # Create the camera with the correct aspect ratio
    aspect_ratio = resolution[0] / resolution[1]
    camera = pyrender.PerspectiveCamera(
        yfov=fov,
        aspectRatio=aspect_ratio,
    )

    # Apply translations
    if camera_pose is None:
        trans = np.array(
            [
                [1.0, 0.0, 0.0, xtrans],
                [0.0, 1.0, 0.0, ytrans],
                [0.0, 0.0, 1.0, ztrans],
                [0.0, 0.0, 0.0, 1.0],
            ]
        )

        # Apply rotations
        xrotmat = trimesh.transformations.rotation_matrix(
            angle=np.radians(xrot), direction=[1, 0, 0], point=(0, 0, 0)
        )
        camera_pose = np.dot(xrotmat, trans)
        yrotmat = trimesh.transformations.rotation_matrix(
            angle=np.radians(yrot), direction=[0, 1, 0], point=(0, 0, 0)
        )
        camera_pose = np.dot(yrotmat, camera_pose)
        zrotmat = trimesh.transformations.rotation_matrix(
            angle=np.radians(zrot), direction=[0, 0, 1], point=(0, 0, 0)
        )
        camera_pose = np.dot(zrotmat, camera_pose)
    logging.debug("Creating camera with pose: \n{}".format(camera_pose))

    # Insert the camera
    scene.add(camera, pose=camera_pose)

    # Insert a spotlight to give contrast
    spot_light = pyrender.SpotLight(
        color=np.ones(3),
        intensity=spotlight_intensity,
        innerConeAngle=np.pi / 16.0,
        outerConeAngle=np.pi / 6.0,
    )
    scene.add(spot_light, pose=camera_pose)

    # Render
    r = pyrender.OffscreenRenderer(resolution[0], resolution[1], point_size=point_size)
    c, d = r.render(scene)
    if modality == "depth":
        return np.array(d)
    elif modality == "color":
        if mode is None:
            return np.array(c)
        return np.array(Image.fromarray(c).convert(mode))
    else:
        raise RuntimeError