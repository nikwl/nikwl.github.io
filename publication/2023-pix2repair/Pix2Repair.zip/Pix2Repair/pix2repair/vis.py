import os
import math
import itertools

import trimesh
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib import tri

import PIL
from PIL import Image, ImageFont


def annotate_image(img, text, vspace=10, hspace=10, fontsize=30, color=(0, 0, 0)):
    """
    Adds a black annotation in the top left corner.
    """
    img = PIL.Image.fromarray(img)
    draw = PIL.ImageDraw.Draw(img)
    draw.text(
        (hspace, vspace), text, color, font=ImageFont.truetype("FreeMono.ttf", fontsize)
    )
    return np.array(img).astype(np.uint8)


def save_image_block(img, name, max_h=50000):
    """some images are too big to save, so this cuts them up"""
    img = np.array(img)
    h = img.shape[0]
    if h > max_h:
        for idx, y in enumerate(range(0, h, max_h)):
            n = name.format(idx)
            bn, ext = os.path.splitext(os.path.basename(n))
            if len(bn) > 255:
                n = os.path.join(os.path.dirname(n), bn[:250] + str(idx) + ext)
            Image.fromarray(img[y : min(y + max_h, h), ...]).save(n)
    else:
        n = name.format(0)
        bn, ext = os.path.splitext(os.path.basename(n))
        if len(bn) > 255:
            n = os.path.join(os.path.dirname(n), bn[:250] + ext)
        Image.fromarray(img).save(n)


def plt2numpy(fig):
    fig.canvas.draw()
    return np.reshape(
        np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8),
        newshape=(int(fig.bbox.bounds[3]), int(fig.bbox.bounds[2]), -1),
    )


def resize(img, size):
    return np.array(Image.fromarray(img).resize(size))


def colorize_shape(mesh, shape, color_strength=60):
    """Applies a predefined color to a mesh based on its shape"""

    # Define the colors
    color_red = [c - color_strength for c in [228, 129, 129]] + [255]  # 168, 69, 69
    # color_grey = [c - color_strength for c in [150, 150, 150]] + [255]
    color_grey = [c - color_strength for c in [240, 240, 240]] + [255]

    # Apply colors
    if shape in ["r"]:
        color_grey[-1] = 128  # Transparency
        mesh.visual = trimesh.visual.color.ColorVisuals(mesh, vertex_colors=color_red)
    else:
        mesh.visual = trimesh.visual.color.ColorVisuals(mesh, vertex_colors=color_grey)
    return mesh


def colorize_values(values, cmap=None, min_max=None):
    # Get the colormap
    if cmap is None:
        cmap = cm.jet

    # Get the min and max
    if min_max is None:
        min_, max_ = values.min(), values.max()
    else:
        min_, max_ = min_max

    # Normalize and clip
    values = np.clip((values - min_) / (max_ - min_), 0.0, 1.0)

    # Can handle inputs that are 1-d vectors, or 2-d arrays with one column
    if len(values.shape) == 1:
        values = (cmap(values)[:, :3] * 255).astype(np.uint8)
    elif values.shape[1] == 1:
        values = (cmap(values.flatten())[:, :3] * 255).astype(np.uint8)

    # Else you already have a colormap
    elif values.shape[1] == 3:
        values = (values * 255).astype(np.uint8)
    else:
        raise RuntimeError(
            "Could not resolve pts colors with shape".format(values.shape[1])
        )
    return values


def parse_samples(pts_values):
    """
    Validates points and values. Also transforms them into a standard representation.

    Args:
        pts_values: Accepts inputs of the following types:
            [pts (tensor), c/b/r (tensor)]
            [pts (tensor), c (tensor), b (tensor), r (tensor)]
            [pts (numpy), c/b/r (numpy)]
            [pts (numpy), c (numpy), b (numpy), r (numpy)]
            [pts+c/b/r (numpy)]
            [pts+c+b+r (numpy)]

    Returns:
        pts (numpy), c+b+r (numpy)
    """
    if isinstance(pts_values, tuple):
        # Was passed a tuple of tensors (output of dataset[idx])
        try:
            if len(pts_values) == 4:
                pts = pts_values[0].numpy()
                assert pts.shape[1] == 3
                c = np.expand_dims(pts_values[1].numpy(), axis=1)
                b = np.expand_dims(pts_values[2].numpy(), axis=1)
                r = np.expand_dims(pts_values[3].numpy(), axis=1)
                values = np.expand_dims(np.hstack((c, b, r)), axis=1)
            elif len(pts_values) == 2:
                pts = pts_values[0].numpy()
                assert pts.shape[1] == 3
                values = pts_values[1].numpy()
                if len(values.shape) == 1:
                    values = np.expand_dims(pts_values[1].numpy(), axis=1)
            else:
                raise RuntimeError(
                    "Could not resolve pts values tuple with length".format(
                        len(pts_values)
                    )
                )
        except AttributeError:
            if len(pts_values) == 4:
                pts = pts_values[0]
                assert pts.shape[1] == 3

                c = np.expand_dims(pts_values[1], axis=1)
                b = np.expand_dims(pts_values[2], axis=1)
                r = np.expand_dims(pts_values[3], axis=1)
                values = np.expand_dims(np.hstack((c, b, r)), axis=1)
            elif len(pts_values) == 2:
                pts = pts_values[0]
                assert pts.shape[1] == 3
                values = pts_values[1]
                if len(values.shape) == 1:
                    values = np.expand_dims(pts_values[1], axis=1)
            else:
                raise RuntimeError(
                    "Could not resolve pts values tuple with length".format(
                        len(pts_values)
                    )
                )
    else:
        if pts_values.shape[1] == 6:
            pts = pts_values[:, :3]
            c = np.expand_dims(pts_values[:, 3], axis=1)
            b = np.expand_dims(pts_values[:, 4], axis=1)
            r = np.expand_dims(pts_values[:, 5], axis=1)
            values = np.expand_dims(np.hstack((c, b, r)), axis=1)
        elif pts_values.shape[1] == 4:
            pts = pts_values[:, :3]
            values = np.expand_dims(pts_values[:, 3], axis=1)
        else:
            raise RuntimeError(
                "Could not resolve pts values array with shape".format(pts_values.shape)
            )

    return pts, values


def plot_samples(
    pts_values,
    slice_dim=0,
    n_plots=4,
    cmap=None,
    min_max=None,
    figsize=3,
    padding=0.05,
    swap_yz=True,
):
    """
    Plot samples in several slices.
    """

    plt.close("all")

    size = int(math.sqrt(n_plots))
    assert size**2 == n_plots, "n_plots must be a perfect square"

    # Get points and values
    pts, values = parse_samples(pts_values)
    if swap_yz:
        pts = pts[:, [0, 2, 1]]
    if min_max is None:
        min_, max_ = values.min(), values.max()
    else:
        min_, max_ = min_max
    if cmap is None:
        cmap = cm.jet
    colors = colorize_values(values, cmap, min_max).astype(float)

    fig, axes = plt.subplots(
        nrows=size, ncols=size, figsize=(figsize * n_plots, figsize * n_plots)
    )
    step_size = (1.0 + (2 * padding)) / n_plots
    for (i, j), r in zip(
        itertools.product(list(range(size)), list(range(size))),
        np.linspace(-0.5 - padding, 0.5 + padding, n_plots, endpoint=False),
    ):
        mask = np.logical_and(
            (pts[:, slice_dim] > r), (pts[:, slice_dim] < (r + step_size))
        )
        p = np.delete(pts[mask, :], slice_dim, axis=1)
        axes[i, j].scatter(p[:, 0], p[:, 1], c=(colors[mask, :] / 255.0))
        axes[i, j].set_xlim(-0.5 - padding, 0.5 + padding)
        axes[i, j].set_ylim(-0.5 - padding, 0.5 + padding)

    # Make colorbar
    cax, kw = mpl.colorbar.make_axes([ax for ax in axes.flat])
    sm = plt.cm.ScalarMappable(
        cmap=cmap, norm=mpl.colors.Normalize(vmin=min_, vmax=max_)
    )
    sm.set_array([])
    fig.colorbar(sm, cax=cax, **kw)

    # Resquare axes
    for ax in axes.flat:
        ax.set_aspect("equal", "box")

    return fig


def vcutstack(img, size=None, fill_color=1):
    """Cuts an image in half vertically and stacks it back together horizontally"""
    h = img.shape[0]
    if size is None:
        return np.hstack((img[: int(h / 2), :, :], img[int(h / 2) :, :, :]))

    # Compute how much is left over
    single_h = size[0]
    leftover = int(h / 2) % single_h

    # If there's any left over, add a blank image
    if leftover != 0:
        prev_shape = list(img.shape)
        prev_shape[0] = size[0]
        img = np.vstack(
            (img, np.ones((prev_shape)).astype(img.dtype) * fill_color * 255)
        )

    return vcutstack(img)