import torch
import numpy as np
import pytorch_lightning as pl
try:
    import wandb
except ImportError:
    pass

from pix2repair.utils import render
from pix2repair.vis import plt2numpy, plot_samples
from pix2repair.data import untranspose_image


class Pix2RepairTrainer(pl.LightningModule):
    def __init__(
        self,
        model,
        specs=None,
        lr=0.0002,
        betas=(0.9, 0.999),
        generator=None,
        generate_num=4,
        data_module=None,
    ):
        super().__init__()

        self.model = model
        self.lr = lr
        self.betas = betas
        self.specs = specs
        self.generator = generator
        self.data_module = data_module
        self.generate_num = generate_num

        # Select a random set of indices to visualize during training
        try:
            self.val_loader = self.data_module.val_dataloader()
            self.indices = np.random.choice(
                np.arange(len(self.val_loader)), size=self.generate_num, replace=False
            )
        except AttributeError:
            pass

    def training_step(self, batch, batch_idx):
        if self.model.device is None:
            self.model.to(self.device)

        losses = self.model.compute_loss(batch)
        self.log_dict(
            {"train_" + k: i for k, i in losses.items()},
            sync_dist=True,
            batch_size=self.specs["batch_size"],
        )

        return losses["loss"]

    def validation_step(self, batch, batch_idx):
        if self.model.device is None:
            self.model.to(self.device)

        losses = self.model.compute_loss(batch)
        self.log_dict(
            {"val_" + k: i for k, i in losses.items()},
            sync_dist=True,
            batch_size=self.specs["batch_size"],
        )

        self.model.eval()
        with torch.no_grad():
            evaluations = self.model.evaluate(batch)
        self.model.train()
        self.log_dict(
            {"val_" + k: i for k, i in evaluations.items()},
            sync_dist=True,
            batch_size=self.specs["batch_size"],
        )

        return losses["loss"]

    def test_step(self, batch, batch_idx):
        if self.model.device is None:
            self.model.to(self.device)

        losses = self.model.compute_loss(batch)
        self.log_dict(
            {"test_" + k: i for k, i in losses.items()},
            sync_dist=True,
            batch_size=self.specs["batch_size"],
        )

        return losses["loss"]

    def on_train_epoch_end(self):
        # Pass the current epoch to the datamodule
        self.data_module.current_epoch = self.current_epoch + 1

    def on_validation_epoch_end(self):
        try:
            self.log_predictions(self.indices)
        except Exception as e:
            print(f"Encountered error while logging: {e}")
        self.model.train()  # Reset to training

    def on_test_epoch_end(self):
        pass

    def configure_optimizers(self):
        if self.lr == "auto":  # This is required to stop Adam from crashing
            self.lr = 0.0
        return torch.optim.Adam(self.parameters(), lr=self.lr, betas=self.betas)

    def log_predictions(self, indices):
        """Generate a meshes for a set of inputs and log them to wandb."""

        # Randomly select a subset of grid points for visualization
        grid_points = self.generator.points.unsqueeze(0)
        inds = np.random.choice(
            np.arange(grid_points.size(1)), size=10000, replace=False
        )

        self.model.eval()  # This is very important

        # Pass and log some data through the network
        input_images = []
        output_logits_c = []
        output_meshes_c = []
        output_logits_r = []
        output_meshes_r = []
        for idx in indices:
            input = torch.from_numpy(self.val_loader.dataset[idx]["inputs"])

            if self.current_epoch == 0:
                img = np.vstack([untranspose_image(i.numpy()) for i in input]).astype(
                    np.uint8
                )
                input_images.append(img)

            input = input.unsqueeze(0)

            with torch.no_grad():
                occ_c, occ_b, occ_r = self.model.forward(
                    grid_points.to(self.device), input.to(self.device)
                )

            # Save the predicted outputs
            img = plt2numpy(
                plot_samples((grid_points[0, inds, :], occ_c[0, inds].cpu()))
            )
            output_logits_c.append(img)
            img = plt2numpy(
                plot_samples((grid_points[0, inds, :], occ_r[0, inds].cpu()))
            )
            output_logits_r.append(img)

            # Save the predicted mesh
            mesh = self.generator.mesh_from_occ(
                occ_c.cpu(),
            )
            # mesh.apply_transform(self.val_loader.dataset.shape_pose(idx))
            # img = self.generator.render_from_mesh(mesh)
            try:
                img = render(
                    mesh,
                    resolution=(224, 224),
                    **self.val_loader.dataset.render_params()
                )
            except ValueError:
                img = np.ones((224, 224, 3), dtype=np.uint8) * 255
            output_meshes_c.append(img)
            mesh = self.generator.mesh_from_occ(occ_r.cpu())
            # mesh.apply_transform(self.val_loader.dataset.shape_pose(idx))
            # img = self.generator.render_from_mesh(mesh)
            try:
                img = render(
                    mesh,
                    resolution=(224, 224),
                    **self.val_loader.dataset.render_params()
                )
            except ValueError:
                img = np.ones((224, 224, 3), dtype=np.uint8) * 255
            output_meshes_r.append(img)

        if self.current_epoch == 0:
            self.logger.experiment.log(
                {"input_images": [wandb.Image(np.hstack(input_images))]}
            )
        self.logger.experiment.log(
            {
                "output_logits_c": [wandb.Image(np.hstack(output_logits_c))],
                "output_meshes_c": [wandb.Image(np.hstack(output_meshes_c))],
                "output_logits_r": [wandb.Image(np.hstack(output_logits_r))],
                "output_meshes_r": [wandb.Image(np.hstack(output_meshes_r))],
            }
        )

        self.model.train()  # Reset to training
