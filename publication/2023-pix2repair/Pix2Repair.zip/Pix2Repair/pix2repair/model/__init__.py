import torch
import torch.nn as nn

from pix2repair.model.decoder import *
from pix2repair.model.encoder import *
import pix2repair.metrics as metrics


def model_resolver(specs, name):
    import pix2repair.model as model

    if specs[name + "_arch"] is None:
        return None
    try:
        return getattr(
            model,
            specs[name + "_arch"],
        )(**specs[name + "_kwargs"])
    except KeyError:
        # kwargs not passed, so return the module
        return getattr(
            model,
            specs[name + "_arch"],
        )


def normalize_points(x):
    """Point normalization function"""
    x = x.clone()
    x[..., 0] = (x[..., 0] - 0.00690064) / 0.783289
    x[..., 1] = (x[..., 1] + 0.01890655) / 0.83232343
    x[..., 2] = (x[..., 2] + 2.978798) / 3.5514073
    return x


class Pix2Repair(nn.Module):
    """Pix2Repair module.
    Handles communication between subnets. Takes one or more images as input and
    predicts a complete and break shape.
    """

    def __init__(
        self,
        encoder,
        decoder_c,
        decoder_b,
        z_dim=0,
        c_dim=512,
        pts_batch=2**18,
        normalize_points=False,
        enable_break_loss=True,
    ):
        super().__init__()

        self.encoder = encoder
        self.decoder_c = decoder_c
        self.decoder_b = decoder_b
        self.z_dim = z_dim
        self.c_dim = c_dim
        self.pts_batch = pts_batch
        self.normalize_pts = normalize_points
        self.enable_break_loss = enable_break_loss

        if not self.enable_break_loss:
            print("+Disabling break loss")
        if self.normalize_pts:
            print("+Using normalized points")

        # print("+Using encoder: ", encoder)
        # print("+Using decoder_c: ", decoder_c)
        # print("+Using decoder_b: ", decoder_b)

        assert self.z_dim == 0
        if self.z_dim == 0:
            self.z = torch.empty((0,))
            self.z.requires_grad = False

        self.device = None

    def evaluate(self, batch):
        """Evaluate voxel points

        Args:
            batch (dict): train batch
        """

        input = batch["inputs"]
        vox_data_c, vox_data_r, vox_pts = (
            batch["vox_data_c"],
            batch["vox_data_r"],
            batch["vox_points"],
        )

        if self.normalize_pts:
            vox_pts = normalize_points(vox_pts)

        prob_c, _, prob_r = self.forward(vox_pts.to(self.device), input.to(self.device))

        prob_c = prob_c.round()
        prob_r = prob_r.round()

        # iou
        vox_iou_r = metrics.iou(
            vox_data_r.type(torch.bool),
            prob_r.type(torch.bool),
        )
        vox_iou_r = vox_iou_r.float()
        vox_iou_c = metrics.iou(
            vox_data_c.type(torch.bool),
            prob_c.type(torch.bool),
        )
        vox_iou_c = vox_iou_c.float()

        # tpr tnr
        tpr_r, tnr_r = metrics.tpr_tnr(
            prob_r.type(torch.bool),
            vox_data_r.type(torch.bool),
        )
        tpr_r, tnr_r = tpr_r.float(), tnr_r.float()
        tpr_c, tnr_c = metrics.tpr_tnr(
            prob_c.type(torch.bool),
            vox_data_c.type(torch.bool),
        )
        tpr_c, tnr_c = tpr_c.float(), tnr_c.float()

        return {
            "vox_r_iou": vox_iou_r,
            "vox_r_tpr": tpr_r,
            "vox_r_tnr": tnr_r,
            "vox_c_iou": vox_iou_c,
            "vox_c_tpr": tpr_c,
            "vox_c_tnr": tnr_c,
        }

    def compute_loss(self, batch):
        """Compute loss on the input

        Args:
            batch (dict): train batch
        """

        inputs, points = batch["inputs"], batch["points"]
        gt_c, gt_b, gt_r = batch["data_c"], batch["data_b"], batch["data_r"]

        if self.normalize_pts:
            points = normalize_points(points)

        c = self.encode(inputs)

        z = self.infer_z(points, None, c)
        logits_c, logits_b = self.decode(points, z, c)

        prob_c = torch.sigmoid(logits_c)
        prob_b = torch.sigmoid(logits_b)

        prob_r = prob_c * prob_b

        loss_c = torch.nn.functional.binary_cross_entropy_with_logits(
            logits_c,
            gt_c,
            reduction="mean",
        )
        loss_b = 0.0
        if self.enable_break_loss:
            loss_b = torch.nn.functional.binary_cross_entropy_with_logits(
                logits_b,
                gt_b,
                reduction="mean",
            )
        loss_r = torch.nn.functional.binary_cross_entropy(
            prob_r,
            gt_r,
            reduction="mean",
        )
        loss = loss_c + loss_b + loss_r

        return {
            "loss": loss,
            "loss_c": loss_c,
            "loss_b": loss_b,
            "loss_r": loss_r,
        }

    def encode(self, inputs):
        """Encodes the input.

        Args:
            input (tensor): the input
        """
        return self.encoder(inputs.squeeze(1))

    def decode(self, p, z, c, **kwargs):
        """Returns occupancy logits for the sampled points.

        Args:
            p (tensor): points
            z (tensor): latent code z
            c (tensor): latent conditioned code c
        """
        logits_c = self.decoder_c(p, z, c)
        logits_b = self.decoder_b(p, z, c)
        return logits_c, logits_b

    def merge(self, p, z, c, o, return_score=False, **kwargs):
        """Passthrough that converts from logits to occupancy.
        This takes in tensors of shape (batch_size, num_inputs, num_pts) and
        returns tensors of shape (batch_size, num_pts).

        Args:
            p (tensor): points
            z (tensor): latent code z
            c (tensor): latent conditioned code c
            o (tensor): predicted occupancy logits
        """
        logits_c, logits_b = o
        prob_c, prob_b = torch.sigmoid(logits_c), torch.sigmoid(logits_b)
        assert (prob_c.ndim == 2) and (prob_b.ndim == 2)
        return prob_c, prob_b

    def infer_z(self, p, occ, c, **kwargs):
        """Infers z.
        By default this does nothing.

        Args:
            p (tensor): points tensor
            occ (tensor): occupancy values for occ
            c (tensor): latent conditioned code c
        """
        return self.z

    def get_z_from_prior(self, size=torch.Size([]), sample=True):
        """Returns z from prior distribution.
        By default this does nothing.

        Args:
            size (Size): size of z
            sample (bool): whether to sample
        """
        return self.z

    def forward(self, p, inputs, sample=True, return_score=False, **kwargs):
        """Performs a forward pass through the network.

        Args:
            p (tensor): sampled points
            inputs (tensor): conditioning input
            sample (bool): whether to sample for z
        """
        batch_size = p.size(0)
        z = self.get_z_from_prior((batch_size,), sample=sample)

        inputs = inputs.to(self.device)  # Ensure inputs are on device
        c = self.encode(inputs)

        return self.decode_batch(p, z, c, return_score)

    def decode_batch(self, p, z, c, return_score=False):
        """A wrapper function to batch points during decoding.

        Args:
            p (tensor): sampled points
            z (tensor): latent code z
            c (tensor): latent conditioned code c
        """
        prob_list_c = []
        prob_list_b = []
        score_list_c = []
        score_list_b = []
        num_points = p.size(1)
        for batch_start in range(0, num_points, self.pts_batch):
            p_batch = p[:, batch_start : batch_start + self.pts_batch, :].to(
                self.device
            )  # Defer transfer to device

            logits_c, logits_b = self.decode(p_batch, z, c)

            if return_score:
                prob_c, prob_b, score_c, score_b = self.merge(
                    p_batch, z, c, (logits_c, logits_b), return_score=True
                )
                score_list_c.append(score_c)
                score_list_b.append(score_b)
            else:
                prob_c, prob_b = self.merge(p_batch, z, c, (logits_c, logits_b))
            prob_list_c.append(prob_c)
            prob_list_b.append(prob_b)

        if return_score:
            score_c, score_b = torch.cat(score_list_c, dim=2), torch.cat(
                score_list_b, dim=2
            )
            score_c = torch.argmax(score_c, dim=1).squeeze(0)
            score_b = torch.argmax(score_b, dim=1).squeeze(0)
        prob_c, prob_b = torch.cat(prob_list_c, dim=1), torch.cat(prob_list_b, dim=1)

        # R = C U B
        prob_r = prob_c * prob_b

        if return_score:
            return prob_c, prob_b, prob_r, score_c, score_b
        return prob_c, prob_b, prob_r

    def to(self, device):
        """Puts the model on the device.

        Args:
            device (device): pytorch device
        """
        model = super().to(device)
        model._device = device
        self.device = device  # Not sure if this is necessary
        return model
