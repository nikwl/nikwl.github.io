import os
import json

import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader, Dataset
import pytorch_lightning as pl


def dataset_resolver(name):
    import pix2repair.data as data

    return getattr(data, name)


def uniform_sample_points(res=256, padding=0.1):
    res = (res, res, res)
    box_size = 1 + padding * 2
    grid_pts = np.meshgrid(*[np.linspace(0, 1.0, d) - (0.5) for d in res])
    pts = np.vstack([p.flatten() for p in grid_pts]).T
    pts *= box_size  # Apply padding
    return pts


def transpose_image(image):
    """Convert a numpy image to an image tensor."""
    return np.transpose(image, axes=(2, 0, 1))


def untranspose_image(image):
    """Convert an image tensor to a numpy image."""
    return np.transpose(image, axes=(1, 2, 0))


def sdf_to_occ(data):
    """Given a sample, convert sdf values to occupancy values."""
    data[data >= 0] = 0.0
    data[data < 0] = 1.0
    return data


def intersect_mesh(a, b, sig=5):
    """mask of vertices that a shares with b"""
    av = [frozenset(np.round(v, sig)) for v in a]
    bv = set([frozenset(np.round(v, sig)) for v in b])
    return np.asarray(list(map(lambda v: v in bv, av))).astype(bool)


def get_faces_from_vertices(vertex_mask, faces, inclusive=False):
    """Get faces containing vertices"""
    vertex_index = set(np.nonzero(vertex_mask)[0])
    face_mask = np.zeros((faces.shape[0],))
    for idx, f in enumerate(faces):
        if inclusive:
            if f[0] in vertex_index and f[1] in vertex_index and f[2] in vertex_index:
                face_mask[idx] = 1
        else:
            if f[0] in vertex_index or f[1] in vertex_index or f[2] in vertex_index:
                face_mask[idx] = 1
    return face_mask.astype(bool)


def get_fracture_vertex_mask(c, b):
    """Return a mask of which points on the broken object that correspond to points not on the fracture"""
    return ~intersect_mesh(b.vertices, c.vertices)


def is_symmetric_fracture(c, b, threshold=0.05):
    """Will return true if the fracture could be repaired using symmetric reflection"""
    mask = get_fracture_vertex_mask(c, b)
    fracture_vertices = b.vertices[mask, :]
    num_total_vertices = len(fracture_vertices)
    num_left_vertices = (fracture_vertices[:, 0] > 0).sum()
    num_right_vertices = (fracture_vertices[:, 0] <= 0).sum()
    if (num_left_vertices < num_total_vertices * threshold) or (
        num_right_vertices < num_total_vertices * threshold
    ):
        return True
    return False


def grid_sample_points(
    n=256,
    padding=0.1,
):
    """Return n^3 points uniformally spaced in a unit cube"""
    grid_pts = np.meshgrid(
        *[np.linspace(0, 1.0 + (padding * 2), d) - (0.5 + padding) for d in (n, n, n)]
    )
    return np.vstack([p.flatten() for p in grid_pts]).T


def select_samples(pts, values, num_samples=None, uniform_ratio=0.5):
    """
    Randomly select a subset of points such that each shape will have at least
    num_samples / (len(shapes) * 2) interior and exterior points.

    Args:
        pts: Points in n dimensional space.
        values: Value at each point. The number of columns gives the number
            of shapes.
        num_samples: Number of samples to return.
        uniform_ratio: Ratio between uniform and surface sampled points.
            Set to 0.5 to disable.
    """
    if uniform_ratio is not None:
        pts, values = select_uniform_ratio_samples(pts, values, uniform_ratio)

    num_shapes = values.shape[1]
    if num_samples is None:
        num_samples = values.shape[0]

    # We want to sample each object about equally
    if num_shapes == 1:
        num_samples = [num_samples]
    else:
        num_samples = [(num_samples // num_shapes) for _ in range(num_shapes - 1)] + [
            num_samples - ((num_shapes - 1) * (num_samples // num_shapes))
        ]

    # Pick the samples fairly
    idx_accumulator = []
    for d, s in zip(values.T, num_samples):
        d = np.expand_dims(d, axis=1)
        pos_inds = np.where(d[:, 0] > 0)[0]
        neg_inds = np.where(d[:, 0] <= 0)[0]
        pos_num, neg_num = (s // 2), (s - (s // 2))

        # Pick negative samples
        if len(neg_inds) > neg_num:
            start_ind = np.random.randint(len(neg_inds) - neg_num)
            neg_picked = neg_inds[start_ind : start_ind + neg_num]
        else:
            try:
                neg_picked = np.random.choice(neg_inds, neg_num)
            except ValueError:
                raise RuntimeError("No samples")

        # Pick positive samples
        if len(pos_inds) > pos_num:
            start_ind = np.random.randint(len(pos_inds) - pos_num)
            pos_picked = pos_inds[start_ind : start_ind + pos_num]
        else:
            try:
                pos_picked = np.random.choice(pos_inds, pos_num)
            except ValueError:
                raise RuntimeError("No samples")

        idx_accumulator.extend([pos_picked, neg_picked])
    idx_accumulator = np.concatenate(idx_accumulator)

    return pts[idx_accumulator, :], values[idx_accumulator, :]


def select_uniform_ratio_samples(pts, values, uniform_ratio=0.5, randomize=True):
    """
    Randomly select a subset of points with a specific uniform ratio.

    Args:
        pts: N-dimensional sample points.
        values: Sdf or occupancy values, same size as pts.
        uniform_ratio: Ratio between uniform and surface sampled points.
            Set to 0.5 to disable.
    """

    # Points will come in split half between uniform and surface
    def adjust_uniform_ratio(data, n_pts, bad_surface=0, bad_uniform=0):
        max_can_select = int(n_pts / 2) - max(bad_surface, bad_uniform)
        surface_ends_at = int(n_pts / 2) - bad_surface

        # We can balance the number of uniform and surface points here
        if uniform_ratio > 0.5:
            select_n_pts = int((max_can_select * (1 - uniform_ratio)) / uniform_ratio)
            selected_pts = np.random.choice(
                max_can_select, size=(select_n_pts), replace=False
            )
            data = np.vstack(
                (
                    data[selected_pts, :],
                    data[surface_ends_at : surface_ends_at + max_can_select, :],
                )
            )
        elif uniform_ratio < 0.5:
            select_n_pts = int((max_can_select * uniform_ratio) / (1 - uniform_ratio))
            selected_pts = (
                np.random.choice(max_can_select, size=(select_n_pts), replace=False)
                + surface_ends_at
            )
            data = np.vstack((data[:max_can_select, :], data[selected_pts, :]))
        else:
            data = np.vstack(
                (
                    data[:max_can_select, :],
                    data[surface_ends_at : surface_ends_at + max_can_select, :],
                )
            )
        return data

    num_dims = pts.shape[1]
    data = np.hstack((pts, values))

    # Adjust the ratio of points if necessary
    if uniform_ratio != 0.5:
        data = adjust_uniform_ratio(data, data.shape[0])

    # Shuffle
    if randomize:
        data = data[np.random.permutation(data.shape[0]), :]
    return data[:, :num_dims], data[:, num_dims:]


class FractureDatamodule(pl.LightningDataModule):
    def __init__(
        self,
        dataset_kwargs,
        dataloader_kwargs,
        dataset_module,
        randomize_num_inputs=False,
    ):
        super(FractureDatamodule, self).__init__()

        self.dataset_kwargs = dataset_kwargs
        self.dataloader_kwargs = dataloader_kwargs
        self.randomize_num_inputs = randomize_num_inputs

        self.current_epoch = 0
        self.num_inputs = dataset_kwargs["num_inputs"]

        self.train_set = dataset_module(split="train", **dataset_kwargs)
        self.val_set = dataset_module(split="val", **dataset_kwargs)

    def train_dataloader(self):
        return DataLoader(self.train_set, shuffle=True, **self.dataloader_kwargs)

    def val_dataloader(self):
        return DataLoader(self.val_set, shuffle=False, **self.dataloader_kwargs)


class FractureDataset(Dataset):
    def __init__(
        self,
        roots,
        split="train",
        image_size=224,
        subsample=2048,
        validate=True,
        num_inputs=False,
        vox_subsample=65536,
        shuffle_fracture_view=False,
    ):
        super(FractureDataset, self).__init__()

        self.split = split
        self.image_size = image_size
        self.subsample = subsample
        self.num_inputs = num_inputs
        self.vox_subsample = vox_subsample
        self.shuffle_fracture_view = shuffle_fracture_view

        assert num_inputs == 1

        # Select a random subset of voxel points for evaluation
        self.vox_pts = grid_sample_points(n=256)
        self.vox_inds = np.random.choice(
            np.arange(self.vox_pts.shape[0]), size=self.vox_subsample, replace=False
        )
        self.vox_pts = self.vox_pts[self.vox_inds, :].astype(np.float32)

        with open(roots, "r") as f:
            self.object_list = json.load(f)
        self.object_list = self.object_list[split]

        # Get data root from environment variable if it exists
        data_root = os.environ.get("DATA_ROOT", None)
        if data_root is not None:
            for o in self.object_list:
                o["root"] = data_root

        self.data = []
        missing_samples = 0
        for o in self.object_list:            
            inputs = [
                os.path.join(
                    o["root"],
                    o["class_id"],
                    o["instance_id"],
                    "models",
                    "model_{}_occ_surf.npz".format(o["break_id"]),
                ),
                os.path.join(
                    o["root"],
                    o["class_id"],
                    o["instance_id"],
                    "models",
                    "model_{}_occ_surf_spline.npz".format(o["break_id"]),
                ),
                os.path.join(
                    o["root"],
                    o["class_id"],
                    o["instance_id"],
                    "renders",
                    "model_b_{}_fracture_view_v2.png".format(o["break_id"]),
                ),
                os.path.join(
                    o["root"],
                    o["class_id"],
                    o["instance_id"],
                    "renders",
                    "model_b_{}_fracture_view.npz".format(o["break_id"]),
                ),
                os.path.join(
                    o["root"],
                    o["class_id"],
                    o["instance_id"],
                    "models",
                    "model_c_{}_vox256.npz".format(o["break_id"]),
                ),
                os.path.join(
                    o["root"],
                    o["class_id"],
                    o["instance_id"],
                    "models",
                    "model_r_{}_vox256.npz".format(o["break_id"]),
                ),
            ]

            if validate and not all([os.path.exists(p) for p in inputs]):
                missing_samples += 1
                continue

            self.data.append(
                {
                    "path_sdf": inputs[0],
                    "path_spline": inputs[1],
                    "path_images": [inputs[2]],
                    "path_image_metadata": [inputs[3]],
                    "path_vox_c": inputs[4],
                    "path_vox_r": inputs[5],
                    "class_id": o["class_id"],
                    "instance_id": o["instance_id"],
                }
            )

        print(
            f"Loaded {len(self.data)} samples: {self.split}, inputs: {self.num_inputs}, missing: {missing_samples}, validation: {validate}"
        )

        if self.split in ["val", "test"]:
            assert missing_samples == 0
            assert len(self.data) == len(self.object_list)

    def __len__(self):
        return len(self.data)

    def render_params(self):
        """Return params for mesh visualization"""
        return dict(
            xtrans=0.0,
            ytrans=0.0,
            ztrans=2.0,
            xrot=-25.0,
            yrot=-45.0,
            zrot=0.0,
        )

    def get_viewpoint(self, index):
        """Return viewpoint for a specific index"""
        return [0]

    def get(self, index, shape="c", type="mesh"):
        """Get specific files from disk.
        Will return the path to a specific file, or metadata about an object.
        """
        assert type in ["mesh", "image", "chamfer", "metadata", "view_metadata"]

        o = self.object_list[index]
        path_model_dir = os.path.join(
            o["root"], o["class_id"], o["instance_id"], "models"
        )

        if type == "mesh":
            if shape == "c":
                path = os.path.join(path_model_dir, "model_c.obj")
            elif shape == "b":
                path = os.path.join(
                    path_model_dir, "model_b_{}.obj".format(o["break_id"])
                )
            elif shape == "r":
                path = os.path.join(
                    path_model_dir, "model_r_{}.obj".format(o["break_id"])
                )
            return path

        elif type == "image":
            return self.data[index]["path_images"][0]

        elif type == "view_metadata":
            return self.data[index]["path_image_metadata"][0]

        elif type == "chamfer":
            assert shape == "r"
            return os.path.join(
                path_model_dir, "model_r_{}_chamfer.npz".format(o["break_id"])
            )

        elif type == "metadata":
            return {
                "class_id": self.data[index]["class_id"],
                "instance_id": self.data[index]["instance_id"],
            }

    def shape_pose(self, index):
        """Return the shape pose for a specific index"""
        return np.eye(4)

    def __getitem__(self, index):
        path_sdf, path_spline = (
            self.data[index]["path_sdf"],
            self.data[index]["path_spline"],
        )
        path_images = self.data[index]["path_images"]
        path_vox_c, path_vox_r = (
            self.data[index]["path_vox_c"],
            self.data[index]["path_vox_r"],
        )

        image_list = [
            transpose_image(np.array(Image.open(path_images[i]))).astype(np.float32)
            for i in self.get_viewpoint(index)
        ]
        inputs = np.stack(image_list, axis=0)

        points = torch.empty((0,))
        data_c, data_r, data_b = torch.empty((0,)), torch.empty((0,)), torch.empty((0,))
        data_vox_c, data_vox_r = torch.empty((0,)), torch.empty((0,))

        with np.load(path_sdf) as f:
            points = f["pts"].astype(np.float32)
            data_sdf = np.unpackbits(f["occ"]).reshape(-1, 3)
            data_c = data_sdf[:, 0].astype(np.float32)
            data_r = data_sdf[:, 2].astype(np.float32)

        with np.load(path_spline) as f:
            data_b = np.unpackbits(f["occ"])
            data_b = data_b.astype(np.float32)

        # Load evaluation data
        data_vox_c, data_vox_r = torch.empty((0,)), torch.empty((0,))
        if self.split == "val":
            with np.load(path_vox_c) as f:
                data_vox_c = np.unpackbits(f["occ"])
                data_vox_c = data_vox_c.astype(np.float32)
                data_vox_c = data_vox_c[self.vox_inds]
            with np.load(path_vox_r) as f:
                data_vox_r = np.unpackbits(f["occ"])
                data_vox_r = data_vox_r.astype(np.float32)
                data_vox_r = data_vox_r[self.vox_inds]

        data = np.stack((data_c, data_b, data_r), axis=1)

        assert data.shape[1] == 3
        assert (
            inputs.shape[0] == self.num_inputs
        ), f"{inputs.shape[0]} vs {self.num_inputs}"

        points, data = select_samples(
            points, data, num_samples=self.subsample, uniform_ratio=0.2
        )
        data_c, data_b, data_r = data[:, 0], data[:, 1], data[:, 2]

        return {
            "inputs": inputs,
            "points": points,
            "data_c": data_c,
            "data_b": data_b,
            "data_r": data_r,
            "vox_data_c": data_vox_c,
            "vox_data_r": data_vox_r,
            "vox_points": self.vox_pts,
        }


class FractureDatasetViewerCentric(FractureDataset):
    def shape_pose(self, index):
        """Transform that moves a shape in camera coords to world coords"""
        path_image_metadata = self.data[index]["path_image_metadata"]
        with np.load(path_image_metadata) as f:
            camera_pose = f["camera_pose"]
            return camera_pose

    def render_params(self):
        """Return params for mesh visualization"""
        return dict(
            camera_pose=np.eye(4),
        )

    def __getitem__(self, index):
        path_sdf, path_spline = (
            self.data[index]["path_sdf"],
            self.data[index]["path_spline"],
        )
        path_images = self.data[index]["path_images"]
        path_vox_c, path_vox_r = (
            self.data[index]["path_vox_c"],
            self.data[index]["path_vox_r"],
        )
        path_image_metadata = self.data[index]["path_image_metadata"]

        image_list = [
            transpose_image(np.array(Image.open(path_images[i]))).astype(np.float32)
            for i in self.get_viewpoint(index)
        ]

        with np.load(path_sdf) as f:
            points = f["pts"].astype(np.float32)
            data_sdf = np.unpackbits(f["occ"]).reshape(-1, 3)
            data_c = data_sdf[:, 0].astype(np.float32)
            data_r = data_sdf[:, 2].astype(np.float32)

        with np.load(path_spline) as f:
            data_b = np.unpackbits(f["occ"])
            data_b = data_b.astype(np.float32)

        data_vox_c, data_vox_r = torch.empty((0,)), torch.empty((0,))
        if self.split == "val":
            with np.load(path_vox_c) as f:
                data_vox_c = np.unpackbits(f["occ"])
                data_vox_c = data_vox_c.astype(np.float32)
                data_vox_c = data_vox_c[self.vox_inds]
            with np.load(path_vox_r) as f:
                data_vox_r = np.unpackbits(f["occ"])
                data_vox_r = data_vox_r.astype(np.float32)
                data_vox_r = data_vox_r[self.vox_inds]

        with np.load(path_image_metadata) as f:
            camera_pose = f["camera_pose"]
            shape_pose = np.linalg.inv(camera_pose)

        data = np.stack((data_c, data_b, data_r), axis=1)
        inputs = np.stack(image_list, axis=0)

        assert data.shape[1] == 3
        assert (
            inputs.shape[0] == self.num_inputs
        ), f"{inputs.shape[0]} vs {self.num_inputs}"

        points, data = select_samples(
            points, data, num_samples=self.subsample, uniform_ratio=0.2
        )
        data_c, data_b, data_r = data[:, 0], data[:, 1], data[:, 2]

        # Apply view transform
        points = (shape_pose[:3, :3] @ points.T).T
        points = points + shape_pose[:3, 3]
        points = points.astype(np.float32)

        # Apply view transform
        vox_pts = self.vox_pts.copy()
        vox_pts = (shape_pose[:3, :3] @ vox_pts.T).T
        vox_pts = vox_pts + shape_pose[:3, 3]
        vox_pts = vox_pts.astype(np.float32)

        return {
            "inputs": inputs,
            "points": points,
            "data_c": data_c,
            "data_b": data_b,
            "data_r": data_r,
            "vox_data_c": data_vox_c,
            "vox_data_r": data_vox_r,
            "vox_points": vox_pts,
        }
