#!/bin/bash

unset PYTHONPATH
source env/bin/activate
export PYTHONPATH=$PYTHONPATH:`pwd`
if [ -d "libs" ]; then
    export PYTHONPATH=$PYTHONPATH:`pwd`/utils/inside_mesh
fi